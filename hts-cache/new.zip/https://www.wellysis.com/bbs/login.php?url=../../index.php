<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


<meta name="description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta name="keywords" content="웰리시스, wellysis, Wellysis, 지능형 알고리즘, 삼성, 삼성 스마트 헬스 프로세서, 디지털 솔루션, 심전도 검사, 실혈관질환 검사" />
<meta property="og:type" content="article">
<meta property="og:title" content="Wellysis">
<meta property="og:description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta property="og:url" content="https://www.wellysis.com/">
<title>Wellysis</title>
<link rel="stylesheet" href="https://www.wellysis.com/theme/wellysis/css/mobile.css?ver=2303229">
<link rel="stylesheet" href="https://www.wellysis.com/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<link rel="stylesheet" href="https://www.wellysis.com/theme/wellysis/mobile/skin/member/basic/style.css?ver=2303229">


<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">

<title>Wellysis</title>
<meta property="og:title" content="Wellysis" />
<meta property="og:type" content="website" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<meta property="og:description" content="" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Robots" content="INDEX, FOLLOW" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" href="/favicon.ico?v=2" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico?v=2" type="image/x-icon">

<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css" />
<link rel="stylesheet" href="/css/j_reset.css">
<link rel="stylesheet" href="/css/j_style.css">
<link rel="stylesheet" href="/css/interwise_all_board.css">
<link rel="stylesheet" href="/css/k_all_board.css">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js" integrity="sha512-qF6akR/fsZAB4Co1QDDnUXWnaQseLGXoniuSuSlPQK6+aWhlMZcHzkasCSlnWoe+TJuudlka1/IQ01Dnhgq95g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollTrigger/1.0.6/ScrollTrigger.min.js" integrity="sha512-+LXqbM6YLduaaxq6kNcjMsQgZQUTdZp7FTaArWYFt1nxyFKlQSMdIF/WQ/VgsReERwRD8w/9H9cahFx25UDd+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="//code.jquery.com/jquery-latest.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
<script src="/js/j_main.js"></script>



<!--[if lte IE 8]>
<script src="https://www.wellysis.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://www.wellysis.com";
var g5_bbs_url   = "https://www.wellysis.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "1";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
	
	
	
	<!-- Google Analytics -->

	<script async src="https://www.googletagmanager.com/gtag/js?id=G-TMD9VCEFJ1"></script>

	<script>  

		window.dataLayer = window.dataLayer || [];  
		function gtag(){dataLayer.push(arguments);}  

		gtag('js', new Date());   
		gtag('config', 'G-TMD9VCEFJ1');

	</script>


	<!-- Naver Analytics -->

	<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>

	<script type="text/javascript">
		
		if(!wcs_add) var wcs_add = {};
		wcs_add["wa"] = "a4cd9bf8185038";

		if(window.wcs) {

		  wcs_do();

		}

	</script>
	
<script src="https://www.wellysis.com/js/jquery-1.12.4.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery-migrate-1.4.1.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery.menu.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/common.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/wrest.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/placeholders.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/modernizr.custom.70111.js?ver=2304171"></script>
</head>
<body oncontextmenu="return false" ondragstart="return false">

<div id="mb_login" class="mbskin">
    <h1>로그인</h1>

    <form name="flogin" action="https://www.wellysis.com/bbs/login_check.php" onsubmit="return flogin_submit(this);" method="post" id="flogin">
    <input type="hidden" name="url" value="..%2F..%2Findex.php">
	
    <div id="login_frm">
		<h2 class="font_b fs_32" style="color: #000; margin-bottom: 30px;">로그인</h2>
        <label for="login_id" class="sound_only">아이디<strong class="sound_only"> 필수</strong></label>
        <input type="text" name="mb_id" id="login_id" placeholder="아이디" required class="frm_input required" maxLength="20">
        <label for="login_pw" class="sound_only">비밀번호<strong class="sound_only"> 필수</strong></label>
        <input type="password" name="mb_password" id="login_pw" placeholder="비밀번호" required class="frm_input required" maxLength="20">
        
        <div id="login_info" class="chk_box">
            <input type="checkbox" name="auto_login" id="login_auto_login" class="selec_chk">
            <label for="login_auto_login"><span></span> 자동로그인</label>
        </div>
		<button type="submit" class="btn_submit">로그인</button>
    </div>

    
    <section class="mb_login_join">
        <h2>회원로그인 안내</h2>
        <div>
            <a href="https://www.wellysis.com/bbs/password_lost.php">아이디/비밀번호 찾기</a>
            <a href="./register.php">회원 가입</a>
        </div>
    </section>
    </form>

        	</div>

<script>
jQuery(function($){
    $("#login_auto_login").click(function(){
        if (this.checked) {
            this.checked = confirm("자동로그인을 사용하시면 다음부터 회원아이디와 비밀번호를 입력하실 필요가 없습니다.\n\n공공장소에서는 개인정보가 유출될 수 있으니 사용을 자제하여 주십시오.\n\n자동로그인을 사용하시겠습니까?");
        }
    });
});

function flogin_submit(f)
{
    if( $( document.body ).triggerHandler( 'login_sumit', [f, 'flogin'] ) !== false ){
        return true;
    }
    return false;
}
</script>



</body>
</html>
