
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


<meta name="description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta name="keywords" content="웰리시스, wellysis, Wellysis, 지능형 알고리즘, 삼성, 삼성 스마트 헬스 프로세서, 디지털 솔루션, 심전도 검사, 실혈관질환 검사" />
<meta property="og:type" content="article">
<meta property="og:title" content="Wellysis">
<meta property="og:description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta property="og:url" content="https://www.wellysis.com/">
<title>Wellysis</title>
<link rel="stylesheet" href="https://www.wellysis.com/theme/wellysis/css/mobile.css?ver=2303229">
<link rel="stylesheet" href="https://www.wellysis.com/js/font-awesome/css/font-awesome.min.css?ver=2303229">


<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">

<title>Wellysis</title>
<meta property="og:title" content="Wellysis" />
<meta property="og:type" content="website" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<meta property="og:description" content="" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Robots" content="INDEX, FOLLOW" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" href="/favicon.ico?v=2" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico?v=2" type="image/x-icon">

<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css" />
<link rel="stylesheet" href="/css/j_reset.css">
<link rel="stylesheet" href="/css/j_style.css">
<link rel="stylesheet" href="/css/interwise_all_board.css">
<link rel="stylesheet" href="/css/k_all_board.css">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js" integrity="sha512-qF6akR/fsZAB4Co1QDDnUXWnaQseLGXoniuSuSlPQK6+aWhlMZcHzkasCSlnWoe+TJuudlka1/IQ01Dnhgq95g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollTrigger/1.0.6/ScrollTrigger.min.js" integrity="sha512-+LXqbM6YLduaaxq6kNcjMsQgZQUTdZp7FTaArWYFt1nxyFKlQSMdIF/WQ/VgsReERwRD8w/9H9cahFx25UDd+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="//code.jquery.com/jquery-latest.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
<script src="/js/j_main.js"></script>



<!--[if lte IE 8]>
<script src="https://www.wellysis.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://www.wellysis.com";
var g5_bbs_url   = "https://www.wellysis.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "1";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
	
	
	
	<!-- Google Analytics -->

	<script async src="https://www.googletagmanager.com/gtag/js?id=G-TMD9VCEFJ1"></script>

	<script>  

		window.dataLayer = window.dataLayer || [];  
		function gtag(){dataLayer.push(arguments);}  

		gtag('js', new Date());   
		gtag('config', 'G-TMD9VCEFJ1');

	</script>


	<!-- Naver Analytics -->

	<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>

	<script type="text/javascript">
		
		if(!wcs_add) var wcs_add = {};
		wcs_add["wa"] = "a4cd9bf8185038";

		if(window.wcs) {

		  wcs_do();

		}

	</script>
	
<script src="https://www.wellysis.com/js/jquery-1.12.4.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery-migrate-1.4.1.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery.menu.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/common.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/wrest.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/placeholders.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/modernizr.custom.70111.js?ver=2304171"></script>
</head>
<body oncontextmenu="return false" ondragstart="return false">
<header id="j_header" class="fixed">
	<div class="j_hd_con">
		<h1 class="hd_logo">
			<a href="/index_en.php">
				<img src="/img/logo/hd_logo.svg" alt="" class="hd_w">
				<img src="/img/logo/hd_logo_m_w.png" alt="" class="hd_m_w">
		
				<img src="/img/logo/hd_logo_b.svg" alt="" class="hd_b">
				<img src="/img/logo/hd_logo_m_b.png" alt="" class="hd_m_b">				
			</a>	
		</h1>
		<div class="hd_right_box">
			<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/en/page0101.php" class="fs_18 font_r"><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/en/page0101.php"><i>Overview</i></a></li>
			<li><a href="/en/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert_en"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/en/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/en/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/en/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/en/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/en/page0204.php"><i>S-Patch AI</i></a></li>	
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news_en" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news_en&sca=Press"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news_en&sca=Event"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news_en&sca=Story"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ_en&sca=Get+Ready" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ_en&sca=Get+Ready"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry_en"><i>Inquiry</i></a></li>	
			<li><a href="/en/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> <!-- 			<button class="web_btn fs_18 font_r j_eng"> -->
<!-- 				<ul> -->
<!-- 					<li> -->
<!-- 						<a href="/" class="web_btn_a">Cardio Web</a> -->
<!-- 						<ul class="web_depth "> -->
<!-- 							<li><a href="">Cardio Web(KR)</a></li> -->
<!-- 							<li><a href="">Cardio Web(AU)</a></li> -->
<!-- 							<li><a href="">Cardio Web(UK)</a></li> -->
<!-- 						</ul> -->
<!-- 					</li> -->
<!-- 				</ul> -->
<!-- 			</button> -->
			<div class="lang_btn j_eng fs_18">
				<a href="/lang.php?lang=kr">KR</a>
				<a href="/index_en.php" class="on">EN</a>
			</div>
		</div>
		<div class="hd_m_box">
			<div class="lang_box j_eng fs_12 font_r">
				<button class="m_lang_btn">EN <i><img src="/img/icon/hd_down_icon.png" alt=""></i></button>
					<ul>
						<li><a href="/lang.php?lang=kr">KR</a></li>						
						<li><a href="/index_en.php" class="on">EN</a></li>
					</ul>			
				</div>
			<button class="nav_btn">
				<span></span>
				<span></span>
				<span></span>
			</button>
		</div>
		<div class="mobile_wrap">
			<div class="mo_inner">
				<nav class="mo_gnb j_eng">
					<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/en/page0101.php" class="fs_18 font_r"><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/en/page0101.php"><i>Overview</i></a></li>
			<li><a href="/en/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert_en"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/en/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/en/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/en/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/en/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/en/page0204.php"><i>S-Patch AI</i></a></li>	
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news_en" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news_en&sca=Press"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news_en&sca=Event"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news_en&sca=Story"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ_en&sca=Get+Ready" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ_en&sca=Get+Ready"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry_en"><i>Inquiry</i></a></li>	
			<li><a href="/en/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> 
				</nav>
			</div>
		</div>
	</div>
	<div class="nav_2depth_bg"></div>
</header>


<script type="text/javascript">
//
//	jQuery(document).ready(function() {
//			$('.pop_content').show();
//	});
	//팝업 Close 기능
	function close_pop(flag) {
		 $('.pop_content').hide();
		
//		$('.pop_submit').hide();
//		$('.pop_cancel').hide();
	};

	
	
	// 세션 상태를 저장하기 위한 변수
	var sessionCookieConsent = sessionStorage.getItem("sessionCookieConsent");

	// 쿠키 동의 여부를 확인하고 팝업을 표시하는 함수
	function checkCookieConsent() {
		if (!getCookie("cookieConsent") && sessionCookieConsent !== "rejected") {
			document.getElementById("cookieConsent").style.display = "block";
		}
	}

	// 쿠키 동의 여부를 저장하는 함수
	function acceptCookies() {
		setCookie("cookieConsent", true, 365); // 쿠키를 1년간 유지
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키 거부 처리하는 함수
	function rejectCookies() {
		sessionStorage.setItem("sessionCookieConsent", "rejected"); // 세션에 쿠키 거부 상태 저장
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키를 설정하는 함수
	function setCookie(name, value, days) {
		var expires = "";
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			expires = "; expires=" + date.toUTCString();
		}
		document.cookie = name + "=" + (value || "") + expires + "; path=/";
	}

	// 쿠키를 가져오는 함수
	function getCookie(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') c = c.substring(1, c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
		}
		return null;
	}

	// 페이지 로드 시 쿠키 동의 여부를 확인
	window.onload = checkCookieConsent;


</script>

<!--쿠키 팝업-->
		<div class="pop_content pop_content_en" id="cookieConsent" style="display:none;">
			<section>
				<h5 class="j_eng fs_22 font_b">Cookie Preferences</h5>
				<div class="pop_txt_wrap">
					
					<div class="pop_txt">					
						<div>
							<span class="j_eng fs_18 font_r">By clicking ‘Accept Cookies’, you agree to the storing of cookies on your device to enhance site navigation, analyze site usage, and assist in our marketing efforts. </span> <br>
							<span class="j_eng fs_18 font_r">If you do not agree, please select ‘Decline’.</span>

						</div>
					</div>
					<div class="pop_btn">
						<button class="pop_submit j_eng fs_18 font_sb fc_f"  onClick="acceptCookies();">Accept Cookies</button>
						<button class="pop_cancel j_eng fs_18 font_sb"  onClick="rejectCookies();">Decline</button>
					</div>
				
				</div>
				

				<div class="pop_form" onClick="close_pop();">         
					<figure>
						<img src="/img/icon/close.png" alt="">
					</figure>
				</div>
			</section>			
		</div>


	<!---게시판 상단 설정 시작--->
	




<!---sub page css--->
<link rel="stylesheet" href="/css/j_sub.css">

<!---sub page js--->
<script src="/js/j_sub.js"></script>

<!---sub page start--->

<!--
<div class="sub_visual">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<h2 class="j_eng fs_48 font_sb base_color"></h2>
				<p class="j_eng fs_22 font_r sub_color01">Compatible with : phone · Tablet · Watch</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/sv_0201.png" alt="" class="pc_img">
					<img src="/img/sub/sv_0201_m.png" alt="" class="mo_img">
				</figure>
			</div>		
		</div>
	</div>	
</div>
<div class="sub_common">
	<div class="j_inner">
		<ul class="tabs">
			<li class="tab-link current" data-tab="tab-1">
				<h4 class="j_eng fs_22 base_color">S-Patch EX</h4> 
				<p class="fs_16 font_m base_color02">Real-time electrocardiogram monitoring for patients</p>
			</li>
			<li class="tab-link" data-tab="tab-2">
				<h4 class="j_eng fs_22 base_color">S-Patch Medi</h4>
				<p class="fs_16 font_m base_color02">Optimal testing efficiency for medical staff</p>
			</li>
		</ul>
	</div>
</div>
-->




<style>
	.main_05{position: relative; z-index: 10;}
</style>

<div class="sub_visual page0201_vs page_vs_en">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<span class="j_eng fs_18 font_b fc_f">S-Patch Wear</span>
				<h2 class="j_eng fs_48 font_b base_color">
					Continuous ECG Monitoring with <br>
					Lightweight & Comfort wearable
				</h2>
				<p class="j_eng fs_22 font_m sub_color01">Choose your device based on the test duration</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/page02/page0201/sv_0201.jpg" alt="" >
				</figure>
			</div>		
		</div>
	</div>	
</div>


<div class="sub_common_rel page0201 page0201_en">
	
		
		<section class="sec01">
			<div class="j_inner">
				<div class="tit_box j_motion common_motion texc">
					<span class="j_eng font_r fs_16 tit_span">S-Patch</span>
					<h2 class="tab_tit j_eng fs_48 font_b">
						Optimized <b style="white-space: nowrap">Test Period.</b><br>
						Minimized Weight.
					</h2>
				</div><!--tit box-->
				<div class="content_wrap j_motion common_motion j_delay_01">
					<figure>
						<img src="/img/sub/page02/page0201/con1.png" alt="" >
					</figure>

					<p class="j_eng fs_22 font_r lh_2">
						<span class="font_sb">S-Patch </span>is just as light as <b class="point point_b fc_f font_b" style="white-space: nowrap;">two sheets of paper.</b>
					</p>
				</div><!--content wrap-->	
			</div>
		</section>
		

	<section class="sec02">		
		<div class="j_inner">							
				<div class="tit_box j_motion common_motion">					
					<h2 class="j_eng fs_40 font_b fc_f">
						Higher arrhythmia detection rate + Keep comfort.<br>
						Long-term continuous ECG patch for extended monitoring.
					</h2>
				</div><!--tit box-->

				<div class="txt_box j_motion common_motion">
					<p class="j_eng fs_20 font_r fc_f">
						Arrhythmia occurs intermittently, resulting in significant differences in detection rates based on the test duration. This is why continuous monitoring for over 24 hours is a necessity.
					</p>
					<p class="j_eng fs_20 font_r fc_f">
						However, merely extending the test period to raise detection causes extreme inconvenience to patients.
						We have found the <b class="point point_w font_b " style="color: #000;">sweet spot</b> - introducing the <b class="font_b">S-Patch solution</b>.
					</p>
				</div><!--txt box-->
				
				<ul class="wear_txt_wrap j_motion common_motion j_delay_01" >
					<li>
						<div class="wear_txt_top">
							<figure><img src="/img/sub/page02/page0201/con2_logo_1.png" alt="" ></figure>
							<p class="j_eng fs_16 font_r" style="color: #bbb">Test Period 1~3 days, Up to 100 hours</p>
						</div>
						<div class="wear_txt_bottom">
							<p class="j_eng fs_20 font_r fc_f">
								A single-lead ECG patch, optimized for the most tolerable duration of test for patients
							</p>								
						</div>
					</li>
					<li>
						<div class="wear_txt_top">
							<figure><img src="/img/sub/page02/page0201/con2_logo_2.png" alt="" ></figure>
							<p class="j_eng fs_16 font_r" style="color: #bbb">Test Period 3~11 days, Up to 264 hours</p>
						</div>
						<div class="wear_txt_bottom">
							<p class="j_eng fs_20 font_r fc_f">
								For extended test period aimed at achieving higher detection rate
							</p>								
						</div>
					</li>
				</ul>
			
		</div>			
	</section>

	<section class="sec03">
		<div class="j_inner">
			<div class="tit_box j_motion common_motion">					
				<h2 class="j_eng fs_48 font_sb">
					Be more surprised with our
				</h2>
			</div><!--tit box-->

			<div class="sec03_tab_wrap">
				<div class="sec03_tab j_motion common_motion">
					<ul>
						<li class="j_eng fs_22 font_m on" data-tab="cont_01"><button type="button">Design</button></li>
						<li class="j_eng fs_22 font_m " data-tab="cont_02"><button type="button">Performance</button></li>
						<li class="j_eng fs_22 font_m " data-tab="cont_03"><button type="button">Usability</button></li>
					</ul>
				</div>
				<div class="sec03_content j_motion common_motion">
					<ul>
						<li id="cont_01" class="on mov mov1">
							<div class="up move">
								<div class="mov_wrap">
	<!--								<figure><img src="/img/sub/page02/page0201/con3.jpg" alt="" ></figure>-->
									<video src="/img/sub/page02/page0201/con3_mov1.mp4" autoplay muted loop playsinline></video>
								</div>
								<ul class="txt_wrap">
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon1.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Light as two sheets of paper. </b>
											The <b class="font_b">9g lightness</b> for long-time monitoring offers comfort. You might forget you are actually wearing a patch. 
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon2.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Trouble-free fit. </b>
											Minimized contact area with the skin <b class="font_b">reduces skin troubles</b> during wearing, and <b class="font_b">decreases noise</b> originating from the skin. 
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon3.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Peace within vibration. </b>
											The cable design connecting both ends of the patch ensures <b class="font_b">stable wear</b> and lowers the risk of falling off during activities.
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon4.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Privacy protected. </b>
											Even when worn, patch doesn’t extend beyond clothing or become visible, ensuring <b class="font_b">uninterrupted daily life</b> even during test.
										</p>
									</li>
								</ul><!--mov1 txt wrap-->						
							</div>						
						</li><!--mov1-->

						<li id="cont_02" class="mov mov2">
							<div class="up">
								<div class="mov_wrap">
									<video src="/img/sub/page02/page0201/con3_mov2.mp4" autoplay muted loop playsinline></video>
								</div>
								<ul class="txt_wrap">
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon5.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">One-step ahead. </b>
											The <b class="font_b">Smart Health Processor by Samsung</b> integrated within the patch shows outstanding capability in collecting various biometric signals, including ECG.
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon6.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Clear P-wave. </b>Flexible lined patch attached to <b class="font_b">Lead II position</b> visualizes ECG waveforms with intact P-waves.
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon7.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Safe even in water-exposed moments. </b>Enhanced with <b class="font_b">IP55 level</b>, now everyday waterproofing is a breeze.
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon8.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Data inflows. Continues. </b>The <b class="font_b">built-in memory</b> ensures that data is continuously stored and retained even when patch-mobile connection is interrupted, enabling stable tests <b class="font_b">without any data loss.</b>
										</p>
									</li>
								</ul><!--mov2 txt wrap-->						
							</div>						
						</li><!--mov2-->

						<li id="cont_03" class="mov mov3">
							<div class="up">
								<div class="mov_wrap">
									<video src="/img/sub/page02/page0201/con3_mov3.mp4" autoplay muted loop playsinline ></video>
								</div>
								<ul class="txt_wrap">
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon9.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Disposing this feels wasteful. </b>S-Patch is <b class="font_b">reusable</b>. No matter how many times it’s used, it always delivers the same performance as new. 
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon10.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Next test - Don’t wait. </b>Forget about charging. <b class="font_b">Quickly swap</b> the electrodes and coin battery to proceed with next test immediately. 
										</p>
									</li>
									<li>
										<figure><img src="/img/sub/page02/page0201/con3_icon11.png" alt="" ></figure>
										<p class="j_eng fs_20 font_m fc_6">
											<b class="fc_0 font_sb">Easy connection. Perfect Control. </b>With the S-Patch app download on your smartphone, tablet, or smartwatch, experience a <b class="font_b">quick-connect</b> and <b class="font_b">comprehensive test management</b> with all of your <b class="font_b">mobile devices. </b>
										</p>
									</li>

								</ul><!--mov3 txt wrap-->						
							</div>						
						</li><!--mov3-->

					</ul>
				</div><!--sec03 content-->
			</div><!--sec03_tab_wrap-->
		</div>		
	</section>
	
	<script>
		$('.sec03_tab ul li').click(function(){
			var tab_id = $(this).attr('data-tab');

			$('.sec03_tab ul li').stop().removeClass('on');
			$('.sec03_content > ul > li').stop().removeClass('on');

			$(this).stop().addClass('on');
			$("#"+tab_id).stop().addClass('on');
		})

	</script>
	
	<section class="sec04">
		<div class="j_inner">
			<div class="tit_box j_motion common_motion">					
				<h2 class="j_eng fs_48 font_sb fc_f">
					S-Patch for everyone.
				</h2>
			</div><!--tit box-->

			<div class="sec04_table_wrap sec04_table_wrap_en j_motion common_motion ">
				<table class="sec04_table">
					<tbody>
						<tr>
							<td>
								<figure><img src="/img/sub/page02/page0201/con4_pro1.png" alt="" ></figure>
								<h4 class="j_eng fs_22 font_b fc_f">S-Patch Ex</h4>
								<p class="j_eng fs_18 fc_9 font_r">Patch-type ECG wearable <br class="br_540x">optimized for arrhythmia detection</p>
							</td>
							
							<td>
								<figure><img src="/img/sub/page02/page0201/con4_pro3.png" alt="" ></figure>
								<h4 class="j_eng fs_22 font_b fc_f">S-Patch ExL</h4>
								<p class="j_eng fs_18 fc_9 font_r">Extended ECG monitoring wearable <br class="br_540x">for higher detection rate</p>
							</td>
						</tr>

						<tr>	
							<td>
								<figure><img src="/img/sub/page02/page0201/con4_smart_thum.png" alt="" ></figure>
								<p class="j_eng fs_16 fc_c font_l mgt_10">Samsung Smart Health Processor</p>
							</td>
							
							<td>
								<figure><img src="/img/sub/page02/page0201/con4_smart_thum.png" alt="" ></figure>
								<p class="j_eng fs_16 fc_c font_l mgt_10">Samsung Smart Health Processor</p>
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Test Period</p>
								<h4 class="j_eng fs_22 font_b fc_f">~3 days</h4>
							</td>
							
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Test Period</p>
								<h4 class="j_eng fs_22 font_b fc_f">~11 days</h4>
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Weight</p>
								<h4 class="j_eng fs_22 font_b fc_f">8.5g</h4>
							</td>
							
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Weight</p>
								<h4 class="j_eng fs_22 font_b fc_f">11g</h4>
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Size</p>
								<h4 class="j_eng fs_22 font_b fc_f">30*190*6mm</h4>
								<figure class="mgt_20 pc_ver"><img src="/img/sub/page02/page0201/con4_size1_en.png" alt="" class="pc_ver"></figure>
								<figure class="mgt_20 mo_ver"><img src="/img/sub/page02/page0201/con4_size1_en_m.png" alt="" class="mo_ver"></figure>
							</td>
							
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Size</p>
								<h4 class="j_eng fs_22 font_b fc_f">30(35)*200*6(8)mm</h4>
								<figure class="mgt_20 pc_ver"><img src="/img/sub/page02/page0201/con4_size3_en.png" alt="" class="pc_ver"></figure>
								<figure class="mgt_20 mo_ver"><img src="/img/sub/page02/page0201/con4_size3_en_m.png" alt="" class="mo_ver"></figure>
							</td>							
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Memory</p>
								<h4 class="j_eng fs_22 font_b fc_f">Built-in</h4>
							</td>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Memory</p>
								<h4 class="j_eng fs_22 font_b fc_f">Built-in</h4>
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Battery</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">CR2032H</h4>
								<p class="j_eng fs_14 fc_f font_l mgt_20">DC 3V Lithium Coin Battery</p>								
							</td>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Battery</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">CR2450</h4>
								<p class="j_eng fs_14 fc_f font_l mgt_20">DC 3V Lithium Coin Battery</p>								
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Electrodes</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">HR-OP42</h4>
<!--								<p class="fs_14 fc_f font_l mgt_20">체외형의료용전극<br>(시중 판매)</p>								-->
							</td>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Electrodes</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">HR-OP42</h4>
<!--								<p class="fs_14 fc_f font_l mgt_20">체외형의료용전극<br>(시중 판매)</p>								-->
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Waterproof</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">IP55</h4>
							</td>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Waterproof</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">IP55</h4>
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Bluetooth</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">BLE 5.1</h4>
							</td>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Bluetooth</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">BLE 5.1</h4>
							</td>
						</tr>
						<tr>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Compatible App</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">S-Patch Ex<br>S-Patch Medi</h4>
							</td>
							<td>
								<p class="j_eng fs_16 fc_c font_l mgb_10">Compatible App</p>
								<h4 class="j_eng fs_22 font_b fc_f j_eng">S-Patch Ex<br>S-Patch Medi</h4>
							</td>
						</tr>
					</tbody>
				</table>
				
				<div class="m_table_txt texc">
					<p class="j_eng fs_18 fc_9 font_r">*Every S-Patch lineup is prepared with Long Lead version : <b class="fc_8f">x2 extended lead length</b> for various body sizes.</p>
				</div>
			</div><!--m_table_wrap-->
			
		</div>
		
	</section>
	
	<section class="sub_page_banner page0102 sub_btn_wrapper">
		<div class="j_inner">
			<ul class="p0202_list p0201_list">					
				<li class="p0202_rt p0201_rt">
					<a href="/en/page0202_ex.php" class="fs_18 font_m j_eng">
						S-Patch App
						<i class="btn_icon">
							<img src="/img/icon/btn_icon_b.png" alt="" class="btn_icon_b">
						</i>
					</a>
				</li>
			</ul>
		</div>
	</section>
	

	
</div>







<div class="side_rail">
	<div class="side_bar">
		<ul>
			 
				<li><a href="javascript:;" class="demo_btn j_eng fs_18 font_r" id="openinquiry">DEMO</a></li>
						<li><a href="/" class="top_btn j_eng fs_18 font_r">TOP</a></li>
		</ul>
		<div class="side_close">
			<a href="/" class="plus_btn"><img src="/img/icon/side_bar_icon.png" alt=""></a>
		</div>
	</div>
</div>
    <footer class="j_footer">
			<div class="main main_05">
				<div class="j_inner02">
					<div class="sec_tit">
						<h2><img src="/img/logo/hd_logo_m_w.png" alt=""></h2>
					</div>
					<ul class="main_05_list j_eng fs_16 font_r j_motion common_motion">
						<li>
							<a href="/en/page0101.php" class="sub_tit">Company</a>
							<a href="/en/page0101.php" class="">Overview</a>
							<a href="/en/page0102.php">Team</a>
							<a href="/bbs/board.php?bo_table=cert_en">IP</a>
						</li>
						<li>
							<a href="/en/page0201.php" class="sub_tit">S-Patch</a>
							<a href="/en/page0201.php" class="">S-Patch Wear</a>
							<a href="/en/page0202_ex.php">S-Patch App</a>
							<a href="/en/page0203.php">S-Patch Web</a>
							<a href="/en/page0204.php">S-Patch AI</a>
						</li>
<!--
						<li>
							<a href="/" class="sub_tit">Service</a>
							<a href="/" class="">Field</a>
							<a href="/">Use Cases</a>
						</li>
-->
						<li>
							<a href="/bbs/board.php?bo_table=news_en" class="sub_tit">News</a>
							<a href="/bbs/board.php?bo_table=news_en&sca=Press" class="">Press</a>
							<a href="/bbs/board.php?bo_table=news_en&sca=Event">Event</a>
							<a href="/bbs/board.php?bo_table=news_en&sca=Story">Story</a>
						</li>
						<li>
							<a href="/bbs/board.php?bo_table=FAQ_en&sca=Get+Ready" class="sub_tit">Support</a>
							<a href="/bbs/board.php?bo_table=FAQ_en&sca=Get+Ready" class="">Manual / FAQ</a>
							<a href="/bbs/write.php?bo_table=inquiry_en">Inquiry</a>
							<a href="/en/page0503.php">Contact</a>
						</li>
						<li>
							<a class="sub_tit" style="cursor: pointer;">S-Patch Web</a>
							<a href="https://kr.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(KR)</a>
							<a href="https://au.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(AU)</a>
							<a href="https://uk.spatchcardio.com/spa/html/login.html" class="" target="_blank">S-Patch Web(EU)</a>
						</li>
						<li class="down_box">
							<p class="sub_tit_down font_m">Download</p>
							<a href="/download/wellysis_brochure_en.pdf" class="down_btn" target="_blank">Brochure <i><img src="/img/icon/down_arrow.png" alt=""></i></a>
							<a href="/en/page06.php" class="sub_tit">Privacy Policy</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="j_inner02">
				<div class="ft_cont">
					<div class="ft_lb">
						<p class="j_eng fs_16 font_r">
<!--							<i>Address: 8F, 425 Teheran-ro, Gangnam-gu, <br class="mo_br"> Seoul, Republic of Korea</i> <br>-->
							<i>Headquarter (Wellysis Corp.) : 8F, 425 Teheran-ro, Gangnam-gu, Seoul, Republic of Korea</i> 
							<br>
							<i class="mt_5">US Office (Wellysis USA, Inc.) : JLABS@TMC, 2450 Holcombe Blvd Suite J, Houston, TX 77021, United States</i>
							<br>
							<i class="mt_5">CEO : Young Juhn</i> <i class="bf_i mt_5">Business License : 774-87-01381</i> <br>
							<i class="mt_5">Phone : + 82 1800 2830</i> <i class="bf_i mt_5">Email : info@wellysis.com</i>
						</p>		
					</div>
					<div class="ft_rb">
						<div class="ft_link">
							<a href="https://youtube.com/@S-Patch?si=iN4f7lZHv_KQGTFE" target="_blank"><img src="/img/icon/you_icon.png" alt="" ></a>
							<a href="https://www.linkedin.com/company/wellysis/" target="_blank"><img src="/img/icon/in_icon.png" alt="" ></a>
						</div>
						<p class="j_eng fs_16 font_l">
							© Wellysis | All rights reserved 2024
						
														<a href="/bbs/login.php?url=../../index.php" style="color:#666;">ADMIN</a>
													</p>
					</div>
				</div>		
			</div>
    </footer>


<style>
.inquiry_overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
}

.overlay-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70vw;
  height: 90vh;
  background-color: #fff;
  padding: 30px 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  border-radius:30px;
  padding: 20px 10px;
}

#closeinquiry {
  position: absolute;
  top: 50px;
  right: 60px;
  color: #fff;
  border: none;
  cursor: pointer;
 
}

.overlay-content iframe {
  width: 100%;
  height: 100%;
}
	
@media (max-width: 1280px){
	#closeinquiry {top: 20px; right: 20px; }
}
@media (max-width: 767px){
	.overlay-content{width: 80vw; height: 80vh;}
}
@media (max-width: 360px){
	.overlay-content{width: 90vw;}
	#closeinquiry {top: 15px; right: 15px;}
}
</style>

 
	<div id="inquiry_overlay" class="inquiry_overlay">
	  <div class="overlay-content">
		<button id="closeinquiry"><img src="/img/icon/demo_close.svg" alt=""></button>
		<iframe src="/bbs/write.php?bo_table=inquiry_en&pop=y" frameborder="0"></iframe>
	  </div>
	</div>

<script>
document.getElementById('openinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'block';
});

document.getElementById('closeinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'none';
});
</script>





</body>
</html>
