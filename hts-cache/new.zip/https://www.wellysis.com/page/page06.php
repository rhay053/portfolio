


<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


<meta name="description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta name="keywords" content="웰리시스, wellysis, Wellysis, 지능형 알고리즘, 삼성, 삼성 스마트 헬스 프로세서, 디지털 솔루션, 심전도 검사, 실혈관질환 검사" />
<meta property="og:type" content="article">
<meta property="og:title" content="Wellysis">
<meta property="og:description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta property="og:url" content="https://www.wellysis.com/">
<title>Wellysis</title>
<link rel="stylesheet" href="https://www.wellysis.com/theme/wellysis/css/mobile.css?ver=2303229">
<link rel="stylesheet" href="https://www.wellysis.com/js/font-awesome/css/font-awesome.min.css?ver=2303229">


<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">

<title>Wellysis</title>
<meta property="og:title" content="Wellysis" />
<meta property="og:type" content="website" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<meta property="og:description" content="" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Robots" content="INDEX, FOLLOW" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" href="/favicon.ico?v=2" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico?v=2" type="image/x-icon">

<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css" />
<link rel="stylesheet" href="/css/j_reset.css">
<link rel="stylesheet" href="/css/j_style.css">
<link rel="stylesheet" href="/css/interwise_all_board.css">
<link rel="stylesheet" href="/css/k_all_board.css">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js" integrity="sha512-qF6akR/fsZAB4Co1QDDnUXWnaQseLGXoniuSuSlPQK6+aWhlMZcHzkasCSlnWoe+TJuudlka1/IQ01Dnhgq95g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollTrigger/1.0.6/ScrollTrigger.min.js" integrity="sha512-+LXqbM6YLduaaxq6kNcjMsQgZQUTdZp7FTaArWYFt1nxyFKlQSMdIF/WQ/VgsReERwRD8w/9H9cahFx25UDd+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="//code.jquery.com/jquery-latest.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
<script src="/js/j_main.js"></script>



<!--[if lte IE 8]>
<script src="https://www.wellysis.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://www.wellysis.com";
var g5_bbs_url   = "https://www.wellysis.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "1";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
	
	
	
	<!-- Google Analytics -->

	<script async src="https://www.googletagmanager.com/gtag/js?id=G-TMD9VCEFJ1"></script>

	<script>  

		window.dataLayer = window.dataLayer || [];  
		function gtag(){dataLayer.push(arguments);}  

		gtag('js', new Date());   
		gtag('config', 'G-TMD9VCEFJ1');

	</script>


	<!-- Naver Analytics -->

	<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>

	<script type="text/javascript">
		
		if(!wcs_add) var wcs_add = {};
		wcs_add["wa"] = "a4cd9bf8185038";

		if(window.wcs) {

		  wcs_do();

		}

	</script>
	
<script src="https://www.wellysis.com/js/jquery-1.12.4.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery-migrate-1.4.1.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery.menu.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/common.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/wrest.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/placeholders.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/modernizr.custom.70111.js?ver=2304171"></script>
</head>
<body oncontextmenu="return false" ondragstart="return false">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">

<header id="j_header" class="fixed">
	<div class="j_hd_con">
		<h1 class="hd_logo">
			<a href="/" id="logoLink">
				<img src="/img/logo/hd_logo.svg" alt="" class="hd_w">
				<img src="/img/logo/hd_logo_m_w.png" alt="" class="hd_m_w">
		
				<img src="/img/logo/hd_logo_b.svg" alt="" class="hd_b">
				<img src="/img/logo/hd_logo_m_b.png" alt="" class="hd_m_b">		
		</a>	
		</h1>
		<div class="hd_right_box">
			<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/page/page0101.php" class="fs_18 font_r "><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/page/page0101.php"><i>Overview</i></a></li>
			<li><a href="/page/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/page/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/page/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/page/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/page/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/page/page0204.php"><i>S-Patch AI</i></a></li>
<!--			<li><a href="/"><i>Interoperability</i></a></li>		-->
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news&sca=보도자료"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news&sca=이벤트"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news&sca=스토리"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry"><i>Inquiry</i></a></li>	
			<li><a href="/page/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> <!-- 			<button class="web_btn fs_18 font_r j_eng"> -->
<!-- 				<ul> -->
<!-- 					<li> -->
<!-- 						<a href="/" class="web_btn_a">Cardio Web</a> -->
<!-- 						<ul class="web_depth "> -->
<!-- 							<li><a href="">Cardio Web(KR)</a></li> -->
<!-- 							<li><a href="">Cardio Web(AU)</a></li> -->
<!-- 							<li><a href="">Cardio Web(UK)</a></li> -->
<!-- 						</ul> -->
<!-- 					</li> -->
<!-- 				</ul> -->
<!-- 			</button> -->
			<div class="lang_btn j_eng fs_18">
				<a href="/index.php" class="on">KR</a>
				<a href="/lang.php?lang=en">EN</a>
			</div>
		</div>
		<div class="hd_m_box">
			<div class="lang_box j_eng fs_12 font_r">
				<button class="m_lang_btn">KR <i><img src="/img/icon/hd_down_icon.png" alt=""></i></button>
					<ul>
						<li><a href="/index.php">KR</a></li>						
						<li><a href="/lang.php?lang=en">EN</a></li>
					</ul>			
				</div>
			<button class="nav_btn">
				<span></span>
				<span></span>
				<span></span>
			</button>
		</div>
		<div class="mobile_wrap">
			<div class="mo_inner">
				<nav class="mo_gnb j_eng">
					<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/page/page0101.php" class="fs_18 font_r "><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/page/page0101.php"><i>Overview</i></a></li>
			<li><a href="/page/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/page/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/page/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/page/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/page/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/page/page0204.php"><i>S-Patch AI</i></a></li>
<!--			<li><a href="/"><i>Interoperability</i></a></li>		-->
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news&sca=보도자료"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news&sca=이벤트"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news&sca=스토리"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry"><i>Inquiry</i></a></li>	
			<li><a href="/page/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> 
				</nav>
			</div>
		</div>
	</div>
	<div class="nav_2depth_bg"></div>
</header>


<script type="text/javascript">
//
//	jQuery(document).ready(function() {
//			$('.pop_content').show();
//	});
	//팝업 Close 기능
	function close_pop(flag) {
		 $('.pop_content').hide();
		
//		$('.pop_submit').hide();
//		$('.pop_cancel').hide();
	};

	
	
	// 세션 상태를 저장하기 위한 변수
	var sessionCookieConsent = sessionStorage.getItem("sessionCookieConsent");

	// 쿠키 동의 여부를 확인하고 팝업을 표시하는 함수
	function checkCookieConsent() {
		if (!getCookie("cookieConsent") && sessionCookieConsent !== "rejected") {
			document.getElementById("cookieConsent").style.display = "block";
		}
	}

	// 쿠키 동의 여부를 저장하는 함수
	function acceptCookies() {
		setCookie("cookieConsent", true, 365); // 쿠키를 1년간 유지
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키 거부 처리하는 함수
	function rejectCookies() {
		sessionStorage.setItem("sessionCookieConsent", "rejected"); // 세션에 쿠키 거부 상태 저장
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키를 설정하는 함수
	function setCookie(name, value, days) {
		var expires = "";
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			expires = "; expires=" + date.toUTCString();
		}
		document.cookie = name + "=" + (value || "") + expires + "; path=/";
	}

	// 쿠키를 가져오는 함수
	function getCookie(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') c = c.substring(1, c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
		}
		return null;
	}

	// 페이지 로드 시 쿠키 동의 여부를 확인
	window.onload = checkCookieConsent;


</script>

<!--쿠키 팝업-->
		<div class="pop_content" id="cookieConsent" style="display:none;">
			<section>
				<h5 class="fs_22 font_b">쿠키 설정</h5>
				<div class="pop_txt_wrap">
					
					<div class="pop_txt">					
						<div>
							<span class="fs_18 font_m">당사에서는 사용자들에 맞춰 사이트를 설정하고 사용자들이 사이트를 보다 원활하게 이용할 수 있도록 쿠키를 사용합니다.</span> <br>
							<span class="fs_18 font_m">만일 당사의 쿠키 사용 정책에 대해 더 알고 싶으신 경우에는</span>
							<a href="/page/page06.php" alt="개인정보처리방침 보기 " class="fs_18 font_b">개인정보처리방침</a> 
							<span class="fs_18 font_m">을 참고하여 주시기 바랍니다.</span>

						</div>
					</div>
					<div class="pop_btn">
						<button class="pop_submit fs_20 font_sb fc_f"  onClick="acceptCookies();">수락</button>
						<button class="pop_cancel fs_20 font_sb"  onClick="rejectCookies();">거부</button>
					</div>
				
				</div>
				

				<div class="pop_form" onClick="close_pop();">         
					<figure>
						<img src="/img/icon/close.png" alt="">
					</figure>
				</div>
			</section>			
		</div>


	<!---게시판 상단 설정 시작--->
	




<!---sub page css--->
<link rel="stylesheet" href="/css/j_sub.css">

<!---sub page js--->
<script src="/js/j_sub.js"></script>

<!---sub page start--->

<!--
<div class="sub_visual">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<h2 class="j_eng fs_48 font_sb base_color"></h2>
				<p class="j_eng fs_22 font_r sub_color01">Compatible with : phone · Tablet · Watch</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/sv_0201.png" alt="" class="pc_img">
					<img src="/img/sub/sv_0201_m.png" alt="" class="mo_img">
				</figure>
			</div>		
		</div>
	</div>	
</div>
<div class="sub_common_rel">
-->
	
	<!--<div class="sub_common">
		<div class="j_inner">
			<ul class="tabs">
				<li class="tab-link current" data-tab="tab-1">
					<h4 class="j_eng fs_22 base_color"></h4> <!-- &page_tab01 -->
	<!--				<p class="fs_16 font_m base_color02">환자를 위한 실시간 심전도 모니터링</p>
				</li>
				<li class="tab-link" data-tab="tab-2">
					<h4 class="j_eng fs_22 base_color"></h4> <!-- &page_tab02 -->
	<!--				<p class="fs_16 font_m base_color02">의료진을 위한 최적의 검사 효율화</p>
				</li>
			</ul>
		</div>
	</div>	-->





<style>

	.sub_visual{display: none;}
	.sub_common_rel{margin-top: 0}
</style>

<div class="sub_common_rel page06">
	<section class="sub_top_wrapper">
		<div class="j_inner">
			

			<div class="sub_top_tit">
				<h2 class="fs_48 font_b">주식회사 웰리시스 개인정보 처리방침</h2>
				<p class="fs_20 font_m lh_5">
					주식회사 웰리시스(이하 ‘회사’’)는 개인정보 보호법에 따라 정보주체의 개인정보를 보호하고 이와 관련한 고충을 <br>
					신속하고 원활하게 처리할 수 있도록 하기 위하여 다음과 같이 개인정보 처리지침을 수립․공개합니다 
				</p>
			</div><!--sub top tit-->
		</div>
	</section>



	<section>
		<div class="j_inner">
			<div class="support_subtxt">
				
				<div class="qna_info">
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제1조</span> 
							<span>개인정보의 처리 목적</span>
						</div>
						
						<p class="info_p01 fs_18">
							회사는 다음의 목적을 위하여 개인정보를 처리합니다. 처리하고 있는 개인정보는 다음의 목적 이외의 용도로는 이용되지 않으며, 이용 목적이 변경되는 경우에는 개인정보 보호법 제18조에 따라 별도의 동의를 받는 등 필요한 조치를 이행할 예정입니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">1. 회원 가입 및 관리</b><br>
							회원 가입의사 확인, 회원제 서비스 제공에 따른 본인 식별 및 인증, 회원자격 유지 및 관리, 서비스 부정이용 방지, 각종 고지 및 통지 등을 목적으로 개인정보를 처리합니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">2. 서비스 제공</b> <br>
							심전도 데이터 측정, 전송 등 서비스(이하 ‘서비스) 제공, 서비스의 개선 등을 목적으로 개인정보를 처리합니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">3. 고충처리</b><br>
							민원인의 신원 확인, 민원사항 확인, 사실조사를 위한 연락․통지, 처리결과 통보 등의 목적으로 개인정보를 처리합니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">4. 서비스이용 및 재화공급 등에 따른 채권채무관계가 잔존하는 경우 채권채무의 이행</b> 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">5. 재가입 검증 및 부정 이용 배제 </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">6. 부정 이용자의 가입 제한 </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">7. 서비스 신뢰도 향상을 위한 데이터 학습, 통계작성, 과학적 연구, 공익적 기록보존 등 </b>
						</p>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제2조</span> 
							<span>개인정보의 처리 및 보유기간</span>
						</div>
						
						<p class="info_p01 fs_18">
							① 회사는 법령에 따른 개인정보 보유․이용기간 또는 정보주체로부터 개인정보를 수집시에 동의받은 개인정보 보유․이용기간 내에서 개인정보를 처리․보유합니다. <br>
							② 각각의 개인정보 처리 및 보유 기간은 다음과 같습니다. 
						</p>
						
						<p class="info_p02 fs_18">
							<b class="font_b">1. 회원 가입 및 관리, 고충처리 : 회원 탈퇴시 까지</b><br>
							다만, 다음의 사유에 해당하는 경우에는 해당 사유 종료시까지 <br>     
							가. 관계 법령 위반에 따른 수사․조사 등이 진행중인 경우에는 해당 수사․조사 종료시까지 <br>     
							나. 서비스 이용에 따른 채권·채무관계 정산 시까지 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">2. 심전도 등 서비스 관련 데이터</b><br>      
							가. 개인정보 수집일로부터 의료법상 진료나 검사 기록을 보관하도록 정해진 기간의 만료일까지 보관함 <br>     
							나. 위탁사로부터 파기 요청이 있는 시점 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">3. 재화 또는 서비스 제공에 대한 이행 및 결제 : 재화 및 서비스 공급완료 및 요금결제, 정산 완료시까지</b><br>
							다만, 다음의 사유에 해당하거나 관련 법령에 근거가 있는 경우에는 해당 기간 종료시까지 가. 개인정보 수집일로부터 의료법상 진료나 검사 기록을 보관하도록 정해진 기간의 만료일까지 보관함 
							<br><br>      
							가. 「전자상거래 등에서의 소비자 보호에 관한 법률」에 따른 표시․광고, 계약내용 및 이행 등 거래에 관한 기록<br> 
							- 표시․광고에 관한 기록 : 6개월 <br>         
							- 계약 또는 청약철회, 대금결제, 재화 등의 공급기록 : 5년 <br>         
							- 소비자 불만 또는 분쟁처리에 관한 기록 : 3년 							
							<br><br>
							나. 「통신비밀보호법 시행령」 제41조에 따른 통신사실확인자료 보관  <br>       
							- 가입자 전기통신일시, 개시․종료시간, 상대방 가입자번호, 사용도수, 발신기지국 위치추적자료 : 1년  <br>       
							- 컴퓨터통신, 인터넷 로그기록자료, 접속지 추적자료 : 3개월 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">4. 재가입 검증 및 부정 이용 배제 : 회원탈퇴 혹은 자격상실일로부터 최대 60일 </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">5. 부정 이용자의 가입 제한 : 부정행위가 끝난 날로부터 1년</b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">6. 개인정보위수탁 계약에 따른 개인정보 : 위수탁계약 종료 시까지 </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">7. 서비스 신뢰도 향상을 위한 데이터 학습, 통계작성, 과학적 연구, 공익적 기록보존 등을 위한 가명정보 : 가명처리 계획 수립 시 정한 목적을 달성하는 시점까지 </b>
						</p>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제3조</span> 
							<span>처리하는 개인정보 항목</span>
						</div>
						<p class="info_p01 fs_18">
							회사는 다음의 개인정보 항목을 처리하고 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">1. 회원 가입 시 </b><br>
							이름, 이메일, 아이디, 비밀번호 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">2. 서비스 이용 시 </b><br>
							가. 피검사자 : 환자등록번호, 이름, 생년월일, 성별, 심전도 측정 데이터 <br>
							나. 의료진 : 아이디, 이름, 비밀번호 
						</p>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제4조</span> 
							<span>개인정보의 제3자 제공</span>
						</div>
						<p class="info_p01 fs_18">
							회사는 이용자의 개인정보를 ‘제1조 개인정보의 처리 목적’에서 고지한 범위 내에서 처리하며, 동의 범위를 초과하여 이용하거나 원칙적으로 제3자에게 제공하지 않습니다. <br>
							다만, 다음의 경우에는 개인정보를 제3자에게 제공할 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">1. 통계작성, 학술연구나 시장조사를 위해 특정 개인을 식별할 수 없는 형태로 가공하여 제공하는 경우 </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">2. 이용자들이 사전에 동의한 경우 </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">3. 법령의 규정에 의거하거나, 수사 목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우 </b>
						</p>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제5조</span> 
							<span>개인 정보의 위탁처리</span>
						</div>
						<p class="info_p01 fs_18 info_p01_table">
							① 회사는 향상된 서비스를 제공하기 위해 개인정보 처리를 아래와 같이 위탁하여 처리하고 있습니다. 
						</p>
						<div class="m_table_wrap">
							<table class="m_table">
							   <tbody>
								   <tr>
									   <td scope="col" alt="본사 주소">
										   <p class="fs_18 font_b">수탁받는 자</p>
									   </td>
									   <td scope="col" alt="위탁업무 내용">
										   <p class="fs_18 font_b">위탁업무 내용</p>
									   </td>
									   <td scope="col" alt="보유 및 이용기간 ">
										   <p class="fs_18 font_b">보유 및 이용기간 </p>
									   </td>
								   </tr>
								   <tr>									   
									   <td scope="col" class="fs_18 font_r">Amazon Web Services, Inc.</td>
									   <td scope="col" class="fs_18 font_r">데이터의 보관</td>
									   <td scope="col" class="fs_18 font_r">위탁 계약 종료 시까지 </td>
								   </tr>
								    <tr>									   
									   <td scope="col" class="fs_18 font_r">제이비내과(대표자: 박정배) </td>
									   <td scope="col" class="fs_18 font_r">심전도 데이터 편집 및 결과 제공</td>
									   <td scope="col" class="fs_18 font_r">위탁 계약 종료 시까지 </td>
								   </tr>
							   </tbody>
						   </table>
					   </div><!--map info-->
						<p class="info_p01 fs_18 info_p01_table">
							② 회사는 위탁계약 체결시 개인정보 보호법 제26조에 따라 위탁업무 수행목적 외 개인정보 처리금지, 기술적․관리적 보호조치, 재위탁 제한, 수탁자에 대한 관리․감독, 손해배상 등 책임에 관한 사항을 계약서 등 문서에 명시하고, 수탁자가 개인정보를 안전하게 처리하는지를 감독하고 있습니다. 
						</p>
						<p class="info_p01 fs_18">
							 ③ 위탁업무의 내용이나 수탁자가 변경될 경우에는 지체없이 본 개인정보 처리방침을 통하여 공개하도록 하겠습니다. 
						</p>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제6조</span> 
							<span>개인정보의 국외이전</span>
						</div>
						<p class="info_p01 fs_18">
							회사는 서비스 제공의 안정성과 최신 기술을 이용자에게 제공하기 위해 국외에 개인정보를 이전하고 있으며, 이용자로부터 취득 또는 생성한 개인정보를 Amazon Web Service(이하 ‘AWS’ )가 보유하고 있는 데이터베이스(물리적 저장 장소: 호주, 영국, 싱가포르)에 저장합니다. AWS는 해당 서버의 물리적인 관리만을 행하고, 이용자의 개인정보에 접근할 수 없습니다. 
						</p>
						<div class="m_table_wrap">
							<table class="m_table m_table02">
							   <tbody>
								   <tr>
									   <td scope="col" alt="수탁업체">
										   <p class="fs_18 font_b">수탁업체</p>
									   </td>
									   <td scope="col" alt="이전항목">
										   <p class="fs_18 font_b">이전항목</p>
									   </td>
									   <td scope="col" alt="이전 국가">
										   <p class="fs_18 font_b">이전 국가</p>
									   </td>
									      <td scope="col" alt="이전 일시 및 방법 ">
										   <p class="fs_18 font_b">이전 일시 및 방법 </p>
									   </td>
									      <td scope="col" alt="보유 및 이용기간">
										   <p class="fs_18 font_b">보유 및 이용기간</p>
									   </td>
								   </tr>
								   <tr>									   
									   <td scope="col" class="fs_18 font_r"> <p class="fs_18 font_m" style="margin-bottom: 10px;">Amazon Web Service</p>담당자: 조민성 이사<br>(02-34309258) </td>
									   <td scope="col" class="fs_18 font_r">서비스 이용 기록 또는 <br>수집된 개인정보</td>
									   <td scope="col" class="fs_18 font_r">호주, 영국, 싱가포르</td>
									   <td scope="col" class="fs_18 font_r">서비스 이용 시점에 <br>네트워크를 통한 전송 </td>
									   <td scope="col" class="fs_18 font_r">해당 개인정보의 보유기간</td>
								   </tr>
							   </tbody>
						   </table>
					   </div><!--map info-->
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제7조</span> 
							<span>이용자의 권리∙의무 및 행사방법</span>
						</div>
						<p class="info_p02 fs_18">
							① 이용자는 회사에 대해 언제든지 개인정보 열람, 정정, 삭제, 처리정지 요구 등의 권리를 행사할 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							② 제1항에 따른 권리 행사는 회사에 대해 관련 법령에 따라 서면, 전자우편 등을 통하여 하실 수 있으며, 회사는 이에 대해 지체없이 조치하겠습니다. 
						</p>
						<p class="info_p02 fs_18">
							③ 제1항에 따른 권리 행사는 정보주체의 법정대리인이나 위임을 받은 자 등 대리인을 통하여 하실 수 있습니다. 이 경우 개인정보 보호법 시행규칙 별지 제11호 서식에 따른 위임장을 제출하셔야 합니다. 
						</p>
						<p class="info_p02 fs_18">
							④ 개인정보 열람 및 처리정지 요구는 관련 법령(개인정보보호법 제35조 제4항, 제37조 제2항 등)에 의하여 정보주체의 권리가 제한될 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							⑤ 개인정보의 정정 및 삭제 요구는 다른 법령에서 그 개인정보가 수집 대상으로 명시되어 있는 경우에는 그 삭제를 요구할 수 없습니다.
						</p>
						<p class="info_p02 fs_18">
							⑥ 회사는 정보주체 권리에 따른 열람의 요구, 정정·삭제의 요구, 처리정지의 요구 시 열람 등 요구를 한 자가 본인이거나 정당한 대리인인지를 확인합니다. 
						</p>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제8조</span> 
							<span>개인정보의 파기 절차 및 방법</span>
						</div>
						<p class="info_p02 fs_18">
							① 회사는 개인정보 보유기간의 경과, 처리목적 달성 등 개인정보가 불필요하게 되었을 때에는 지체 없이 개인정보를 파기합니다. 
						</p>
						<p class="info_p02 fs_18">
							② 정보주체로부터 동의받은 개인정보 보유기간이 경과하거나 처리목적이 달성되었음 에도 불구하고 다른 법령에 따라 개인정보를 계속 보존하여야 하는 경우에는, 해당 개인정보를 별도의 데이터베이스(DB)로 옮기거나 보관장소를 달리하여 보존합니다. 
						</p>
						<p class="info_p02 fs_18">
							③ 개인정보 파기 절차 및 방법은 다음과 같습니다. 							
						</p>
						<div class="info_txt font_16">
							<b class="font_b">1. 파기절차 </b>: 회사는 파기 사유가 발생한 개인정보를 선정하고, 회사의 개인정보 보호책임자의 승인을 받아 개인정보를 파기합니다. 
							<br>
							<b class="font_b">2. 파기방법 </b> : 회사는 전자적 파일 형태로 기록·저장된 개인정보는 기록을 재생할 수 없도록 파기하며, 종이 문서에 기록·저장된 개인정보는 분쇄기로 분쇄 하거나 소각하여 파기합니다. 
						</div>
					</div>

					<div class="pri_line"></div>

					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제9조</span> 
							<span>미이용자의 개인정보 파기 등에 관한 조치</span>
						</div>
						
						<p class="info_p02 fs_18">
							① 회사는 1년간 서비스를 이용하지 않은 이용자의 정보를 파기하고 있습니다. 다만, 다른 법령에서 정한 보존기간이 경과할 때까지 다른 이용자의 개인정보와 분리하여 별도로 저장·관리할 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							② 회사는 개인정보의 파기 30일 전까지 개인정보가 파기되는 사실, 기간 만료일 및 파기되는 개인정보의 항목을 이메일, 문자 등 이용자에게 통지 가능한 방법으로 알리고 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							③ 개인정보의 파기를 원하지 않으시는 경우, 기간 만료 전 서비스 로그인을 하시면 됩니다. 
						</p>
						
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제10조</span> 
							<span>정보주체와 법정대리인의 권리∙의무 및 행사방법</span>
						</div>
						
						<p class="info_p02 fs_18">
							① 정보주체는 회사에 대해 언제든지 개인정보 열람, 정정 요구 등의 권리를 행사할 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							② 권리 행사는 회사에 대해 관련 법령에 따라 서면, 전자우편 등을 통하여 하실 수 있으며, 회사는 이에 대해 지체없이 조치하겠습니다. 
						</p>
						<p class="info_p02 fs_18">
							③ 권리 행사는 정보주체의 법정대리인이나 위임을 받은 자 등 대리인을 통하여 하실 수도 있습니다. 이 경우 “개인정보 처리 방법에 관한 고시(제2020-7호)” 별지 제11호 서식에 따른 위임장을 제출하셔야 합니다. 
						</p>
						<p class="info_p02 fs_18">
							④ 개인정보 열람 및 처리정지 요구는 「개인정보 보호법」 제35조 제4항, 제37조 제2항에 의하여 정보주체의 권리가 제한 될 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							⑤ 개인정보의 정정 및 삭제 요구는 다른 법령에서 그 개인정보가 수집 대상으로 명시되어 있는 경우에는 그 삭제를 요구할 수 없습니다.
						</p>
						<p class="info_p02 fs_18">
							⑥ 회사는 정보주체 권리에 따른 열람의 요구, 정정·삭제의 요구, 처리 정지의 요구 시 열람 등 요구를 한 자가 본인이거나 정당한 대리인인지를 확인합니다. 
						</p>
						
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제11조</span> 
							<span>개인정보의 안전성 확보조치</span>
						</div>
						
						<p class="info_p01 fs_18">
							회사는 이용자의 개인정보를 처리함에 있어 개인정보가 분실, 도난, 유출, 변조 또는 훼손되지 않도록 안전성 확보를 위하여 다음과 같은 기술적∙관리적∙물리적 조치를 취하고 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">1. 관리적 조치</b> : 내부관리계획 수립·시행, 전담조직 운영, 정기적 직원 교육 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">2. 기술적 조치</b> : 개인정보처리시스템 등의 접근권한 관리, 접근통제시스템 설치, 개인정보의 암호화, 보안프로그램 설치 및 갱신 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">3. 물리적 조치</b> : 전산실, 자료보관실 등의 접근통제
						</p>
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제12조</span> 
							<span>개인정보 자동 수집 장치의 설치•운영 및 거부에 관한 사항</span>
						</div>
					
						<p class="info_p02 fs_18">
							① 회사는 이용자에게 개별적인 맞춤서비스를 제공하기 위해 이용 정보를 저장하고 수시로 불러오는 ‘쿠키(cookie)’를 사용할 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							② 쿠키는 웹사이트를 운영하는데 이용되는 서버(http)가 이용자의 컴퓨터 브라우저에게 보내는 소량의 정보이며 이용자들의 PC 컴퓨터내의 하드디스크에 저장되기도 합니다. 
							
						</p>	
						<div class="info_txt font_16">
							<b class="font_b">1. 쿠키의 사용목적</b>: 이용자가 방문한 각 서비스와 웹 사이트들에 대한 방문 및 이용형태, 인기 검색어, 보안접속 여부, 등을 파악하여 이용자에게 최적화된 정보 제공을 위해 사용됩니다. <br>
							<b class="font_b">2. 쿠키의 설치·운영 및 거부</b> : 웹브라우저 상단의 도구>인터넷 옵션>개인정보 메뉴의 옵션 설정을 통해 쿠키 저장을 거부 할 수 있습니다. <br>
							<b class="font_b">3. 쿠키 저장을 거부할 경우 맞춤형 서비스 이용에 어려움이 발생할 수 있습니다.</b>
						</div>
					</div>

					<div class="pri_line"></div>
					
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제13조</span> 
							<span>개인정보 보호책임자</span>
						</div>
						
						<p class="info_p02 fs_18">
							① 회사는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 이용자의 불만처리 및 피해구제 등을 위하여 아래와 같이 개인정보보호 책임자와 실무자를 지정하고 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							- 개인정보 책임자 : 김홍렬 이사 <br>
							- 전화 : 1800-2830 <br>
							- 메일 : info@wellysis.com 
						</p>	
						<p class="info_p02 fs_18">
							- 개인정보보호 실무담당자 : 원성준 <br>
							- 전화 : 1670-2535 <br>
							- 메일 : spatch.cardio@wellysis.com 
						</p>
						<p class="info_p02 fs_18">
							② 이용자는 회사의 서비스를 이용하면서 발생한 모든 개인정보보호 관련 문의, 불만처리, 피해구제 등에 관한 사항을 개인정보 보호책임자 및 담당부서로 문의하실 수 있습니다. 회사는 이용자의 문의에 대해 지체 없이 답변 및 처리합니다. 
						</p>
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제14조</span> 
							<span>가명정보의 처리</span>
						</div>
						
						<p class="info_p02 fs_18">
							회사는 다음과 같은 목적 등으로 가명처리한 개인정보인 가명정보를 처리하고 있습니다.  
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">1. 회사는 서비스 신뢰도 향상을 위한 데이터 학습, 통계작성, 과학적 연구, 공익적 기록보전 등을 위한 목적으로 가명정보를 처리합니다. </b>
						</p>	
						<p class="info_p02 fs_18">
							<b class="font_b">2. 가명정보는 가명처리 계획 수립 시 정한 목적을 달성하는 시점까지만 보유·이용됩니다.</b> 
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">3. 회사는 이름, 환자등록번호를 가명처리하여, 심전도, 성별, 나이 정보를 사용하고 있습니다. </b>
						</p>
						<p class="info_p02 fs_18">
							<b class="font_b">4. 가명정보의 안전성 확보조치에 관한 사항 : 회사는 가명정보를 처리하는 경우 원래의 상태로 복원하기 위한 추가 정보를 별도로 분리하여 보관·관리하고 있습니다. </b> 
						</p>
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제15조</span> 
							<span>개인정보 열람청구</span>
						</div>
						<p class="info_p01 fs_18">
							회사는 이용자의 개인정보를 보호하고 소중하게 생각하며, 이용자는 의문사항으로부터 언제나 성실한 답변을 받을 권리가 있습니다. 회사는 이용자와의 원활한 의사소통을 위해 고객센터를 운영하고 있으며 연락처는 다음과 같습니다.  
						</p>
						<p class="info_p02 fs_18">
							- 부서명 : 운영지원 <br>
							- 담당자 : 원성준 <br>
							- 메일: spatch.cardio@wellysis.com 
						</p>	
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제16조</span> 
							<span>권익침해 구제방법</span>
						</div>
						<p class="info_p02 fs_18">
							① 정보주체는 개인정보침해로 인한 구제를 받기 위하여 개인정보분쟁조정위원회, 한국인터넷진흥원 개인정보침해신고센터 등에 분쟁해결이나 상담 등을 신청할 수 있습니다. 이 밖에 기타 개인정보침해의 신고, 상담에 대하여는 아래의 기관에 문의하시기 바랍니다. 
						</p>
						<div class="info_txt font_16">
							4. 개인정보분쟁조정위원회 : (국번없이) 1833-6972 (www.kopico.go.kr) <br>
							5. 개인정보침해신고센터 : (국번없이) 118 (privacy.kisa.or.kr) <br>
							6. 대검찰청 : (국번없이) 1301 (www.spo.go.kr) <br>
							7. 경찰청 : (국번없이) 182 (ecrm.cyber.go.kr) 
						</div>
						<p class="info_p02 fs_18">
							② 회사는 정보주체의 개인정보자기결정권을 보장하고, 개인정보 침해로 인한 상담 및 피해 구제를 위해 노력하고 있으며, 신고나 상담이 필요한 경우 아래의 담당부서로 연락해 주시기 바랍니다. 
						</p>
						<div class="info_txt font_16">
							- 개인정보보호 관련 상담 및 신고 <br>
							- 부서명 : 정보보안파트 <br>
							- 담당자 : 김홍렬 <br>
							- 연락처 : 1800-2830 
						</div>
						<p class="info_p02 fs_18">
							「개인정보 보호법」 제35조(개인정보의 열람), 제36조(개인정보의 정정·삭제), 제37조(개인정보의 처리정지 등)의 규정에 의한 요구에 대 하여 공공기관의 장이 행한 처분 또는 부작위로 인하여 권리 또는 이익의 침해를 받은 자는 행정심판법이 정하는 바에 따라 행정심판을 청구할 수 있습니다.
						</p>
						<div class="info_txt font_16">
							- 중앙행정심판위원회 : (국번없이) 110 (www.simpan.go.kr) 
						</div>
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t"><br>
						<div class="info_tit">
							<span class="info_num">제17조</span> 
							<span>GDPR의 준수</span>
						</div>

						<p class="info_p02 fs_18">
							① 회사는 유럽연합 일반 개인정보보호법(General Data Protection Regulation) 및 각 회원국의 법률을 준수합니다. 유럽연합 내 이용자를 대상으로 서비스를 제공하는 경우, 아래 내용이 적용될 수 있습니다
						</p>
						<div class="info_txt font_16">
							<b class="font_b">1. 회사는 수집한 개인정보를 제1조에 기재된 목적으로만 이용하며, 사전에 이용자에게 해당 사실을 알리고 동의를 구하고 있습니다. 그리고 GDPR 등 적용되는 법령에 따라, 회사는 아래 하나에 해당하는 경우에 이용자의 개인정보를 처리할 수 있습니다. </b>
							<br>
							가. 정보주체의 동의 <br>
							나. 정보주체와의 계약의 체결 및 이행을 위한 경우 <br>
							다. 법적 의무사항 준수를 위한 경우 <br>
							라. 정보주체의 중대한 이익을 위해 처리가 필요한 경우 <br>
							마. 회사의 적법한 이익 추구를 위한 경우(정보주체의 이익과 권리 또는 자유가 그 이익보다 중요한 경우는 제외) 
							
						</div>
						<p class="info_p02 fs_18">
							② 회사는 이용자의 개인정보를 소중하게 보호합니다. GDPR 등 적용되는 법률에 따라, 이용자는 자신의 개인정보를 다른 관리자에게 이전해 달라고 요청할 수 있고, 자신의 정보 처리 거부를 요청할 수 있습니다. 그리고 이용자는 개인정보보호 권한 당국에 불만을 제기할 권리가 있습니다.  
						</p>
						<p class="info_p02 fs_18">
							③ 회사는 이벤트 및 광고 등 마케팅을 제공하기 위해 개인정보를 활용할 수 있으며, 사전에 이용자의 동의를 구하고 있습니다. 이용자는 원하지 않은 경우 언제든지 동의를 철회할 수 있습니다. 
						</p>
						<p class="info_p02 fs_18">
							④ 본 조와 관련한 요청사항은 고객센터를 통해 서면, 전화 또는 이메일로 연락하시면 지체 없이 조치하겠습니다. 
						</p>
						<p class="info_p02 fs_18">
							⑤ 개인정보의 오류에 대한 정정을 요청하신 경우 정정을 완료하기 전까지 해당 개인정보를 이용 또는 제공하지 않습니다. 
						</p>
					</div>

					<div class="pri_line"></div>
					
					<div class="info_t">
						<div class="info_tit">
							<span class="info_num">제18조</span> 
							<span>개인정보 처리방침 변경에 관한 사항</span>
						</div>
						
						<p class="info_p02 fs_18">
							① 이 개인정보 처리방침은 2022. 06. 13.부터 적용됩니다
						</p>
						
					</div>
				</div>
			
		</div>
			
		</div><!--inner-->
	</section>

</div>








<div class="side_rail">
	<div class="side_bar">
		<ul>
		 
			<li><a href="javascript:;" class="demo_btn j_eng fs_18 font_r" id="openinquiry">DEMO</a></li>
					<li><a href="/" class="top_btn j_eng fs_18 font_r">TOP</a></li>
		</ul>
		<div class="side_close">
			<a href="/" class="plus_btn"><img src="/img/icon/side_bar_icon.png" alt=""></a>
		</div>
	</div>
</div>
    <footer class="j_footer">
			<div class="main main_05">
				<div class="j_inner02">
					<div class="sec_tit">
						<h2><img src="/img/logo/hd_logo_m_w.png" alt=""></h2>
					</div>
					<ul class="main_05_list j_eng fs_16 font_r j_motion common_motion">
						<li>
							<a href="/page/page0101.php" class="sub_tit">Company</a>
							<a href="/page/page0101.php" class="">Overview</a>
							<a href="/page/page0102.php">Team</a>
							<a href="/bbs/board.php?bo_table=cert">IP</a>
						</li>
						<li>
							<a href="/page/page0201.php" class="sub_tit">S-Patch</a>
							<a href="/page/page0201.php" class="">S-Patch Wear</a>
							<a href="/page/page0202_ex.php">S-Patch App</a>
							<a href="/page/page0203.php">S-Patch Web</a>
							<a href="/page/page0204.php">S-Patch AI</a>
<!--							<a href="/">interoperability</a>	-->
						</li>
<!--
						<li>
							<a href="/" class="sub_tit">Service</a>
							<a href="/" class="">Field</a>
							<a href="/">Use Cases</a>
						</li>
-->
						<li>
							<a href="/bbs/board.php?bo_table=news" class="sub_tit">News</a>
							<a href="/bbs/board.php?bo_table=news&sca=보도자료" class="">Press</a>
							<a href="/bbs/board.php?bo_table=news&sca=이벤트">Event</a>
							<a href="/bbs/board.php?bo_table=news&sca=스토리">Story</a>
						</li>
						<li>
							<a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="sub_tit">Support</a>
							<a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="">Manual / FAQ</a>
							<a href="/bbs/write.php?bo_table=inquiry">Inquiry</a>
							<a href="/page/page0503.php">Contact</a>
						</li>
						<li>
							<a class="sub_tit" style="cursor: pointer;">S-Patch Web</a>
							<a href="https://kr.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(KR)</a>
							<a href="https://au.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(AU)</a>
							<a href="https://uk.spatchcardio.com/spa/html/login.html" class="" target="_blank">S-Patch Web(EU)</a>
						</li>
						<li class="down_box">
							
							<p class="sub_tit_down font_m">Download</p>
							<a href="/download/wellysis_brochure_kr.pdf" class="down_btn" target="_blank">Brochure <i><img src="/img/icon/down_arrow.png" alt=""></i></a>
							<a href="/page/page06.php" class="sub_tit" style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">개인정보처리방침</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="j_inner02">
				<div class="ft_cont">
					<div class="ft_lb">
						<p class="j_eng fs_16 font_r">
<!--							<i>Address: 8F, 425 Teheran-ro, Gangnam-gu, <br class="mo_br"> Seoul, Republic of Korea</i> <br>-->
							<i style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">본사 : 서울시 강남구 테헤란로 425, 8층</i> 
							<br>
							<i class="mt_5"><b style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">미국 지사 :</b> JLABS@TMC, 2450 Holcombe Blvd Suite J, Houston, TX 77021, United States</i>
							<br>
							<i class="mt_5">CEO : Young Juhn</i> <i class="bf_i mt_5">Business License : 774-87-01381</i> <br>
							<i class="mt_5">Phone : + 82 1800 2830</i> <i class="bf_i mt_5">Email : info@wellysis.com</i>
						</p>	
					</div>
					<div class="ft_rb">
						<div class="ft_link">
							<a href="https://youtube.com/@S-Patch?si=iN4f7lZHv_KQGTFE" target="_blank"><img src="/img/icon/you_icon.png" alt="" ></a>
							<a href="https://www.linkedin.com/company/wellysis/" target="_blank"><img src="/img/icon/in_icon.png" alt="" ></a>
						</div>
						<p class="j_eng fs_16 font_l">© Wellysis | All rights reserved 2024						
						
														<a href="/bbs/login.php?url=../../index.php" style="color:#666;">ADMIN</a>
													</p>
					</div>
				</div>		
			</div>
    </footer>

<style>
.inquiry_overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
}

.overlay-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70vw;
  height: 90vh;
  background-color: #fff;
  padding: 30px 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  border-radius:30px;
  padding: 20px 10px;
}

#closeinquiry {
  position: absolute;
  top: 50px;
  right: 60px;
  color: #fff;
  border: none;
  cursor: pointer;
 
}

.overlay-content iframe {
  width: 100%;
  height: 100%;
}
	
@media (max-width: 1280px){
	#closeinquiry {top: 20px; right: 20px; }
}
@media (max-width: 767px){
	.overlay-content{width: 80vw; height: 80vh;}
}
@media (max-width: 360px){
	.overlay-content{width: 90vw;}
	#closeinquiry {top: 15px; right: 15px;}
}
</style>

 
	<div id="inquiry_overlay" class="inquiry_overlay">
	  <div class="overlay-content">
		<button id="closeinquiry"><img src="/img/icon/demo_close.svg" alt=""></button>
		<iframe src="/bbs/write.php?bo_table=inquiry&pop=y" frameborder="0"></iframe>
	  </div>
	</div>

<script>
document.getElementById('openinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'block';
});

document.getElementById('closeinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'none';
});
</script>






</body>
</html>
