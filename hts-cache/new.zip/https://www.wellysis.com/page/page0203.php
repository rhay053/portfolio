
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


<meta name="description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta name="keywords" content="웰리시스, wellysis, Wellysis, 지능형 알고리즘, 삼성, 삼성 스마트 헬스 프로세서, 디지털 솔루션, 심전도 검사, 실혈관질환 검사" />
<meta property="og:type" content="article">
<meta property="og:title" content="Wellysis">
<meta property="og:description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta property="og:url" content="https://www.wellysis.com/">
<title>Wellysis</title>
<link rel="stylesheet" href="https://www.wellysis.com/theme/wellysis/css/mobile.css?ver=2303229">
<link rel="stylesheet" href="https://www.wellysis.com/js/font-awesome/css/font-awesome.min.css?ver=2303229">


<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">

<title>Wellysis</title>
<meta property="og:title" content="Wellysis" />
<meta property="og:type" content="website" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<meta property="og:description" content="" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Robots" content="INDEX, FOLLOW" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" href="/favicon.ico?v=2" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico?v=2" type="image/x-icon">

<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css" />
<link rel="stylesheet" href="/css/j_reset.css">
<link rel="stylesheet" href="/css/j_style.css">
<link rel="stylesheet" href="/css/interwise_all_board.css">
<link rel="stylesheet" href="/css/k_all_board.css">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js" integrity="sha512-qF6akR/fsZAB4Co1QDDnUXWnaQseLGXoniuSuSlPQK6+aWhlMZcHzkasCSlnWoe+TJuudlka1/IQ01Dnhgq95g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollTrigger/1.0.6/ScrollTrigger.min.js" integrity="sha512-+LXqbM6YLduaaxq6kNcjMsQgZQUTdZp7FTaArWYFt1nxyFKlQSMdIF/WQ/VgsReERwRD8w/9H9cahFx25UDd+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="//code.jquery.com/jquery-latest.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
<script src="/js/j_main.js"></script>



<!--[if lte IE 8]>
<script src="https://www.wellysis.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://www.wellysis.com";
var g5_bbs_url   = "https://www.wellysis.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "1";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
	
	
	
	<!-- Google Analytics -->

	<script async src="https://www.googletagmanager.com/gtag/js?id=G-TMD9VCEFJ1"></script>

	<script>  

		window.dataLayer = window.dataLayer || [];  
		function gtag(){dataLayer.push(arguments);}  

		gtag('js', new Date());   
		gtag('config', 'G-TMD9VCEFJ1');

	</script>


	<!-- Naver Analytics -->

	<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>

	<script type="text/javascript">
		
		if(!wcs_add) var wcs_add = {};
		wcs_add["wa"] = "a4cd9bf8185038";

		if(window.wcs) {

		  wcs_do();

		}

	</script>
	
<script src="https://www.wellysis.com/js/jquery-1.12.4.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery-migrate-1.4.1.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery.menu.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/common.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/wrest.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/placeholders.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/modernizr.custom.70111.js?ver=2304171"></script>
</head>
<body oncontextmenu="return false" ondragstart="return false">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">

<header id="j_header" class="fixed">
	<div class="j_hd_con">
		<h1 class="hd_logo">
			<a href="/" id="logoLink">
				<img src="/img/logo/hd_logo.svg" alt="" class="hd_w">
				<img src="/img/logo/hd_logo_m_w.png" alt="" class="hd_m_w">
		
				<img src="/img/logo/hd_logo_b.svg" alt="" class="hd_b">
				<img src="/img/logo/hd_logo_m_b.png" alt="" class="hd_m_b">		
		</a>	
		</h1>
		<div class="hd_right_box">
			<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/page/page0101.php" class="fs_18 font_r "><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/page/page0101.php"><i>Overview</i></a></li>
			<li><a href="/page/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/page/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/page/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/page/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/page/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/page/page0204.php"><i>S-Patch AI</i></a></li>
<!--			<li><a href="/"><i>Interoperability</i></a></li>		-->
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news&sca=보도자료"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news&sca=이벤트"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news&sca=스토리"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry"><i>Inquiry</i></a></li>	
			<li><a href="/page/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> <!-- 			<button class="web_btn fs_18 font_r j_eng"> -->
<!-- 				<ul> -->
<!-- 					<li> -->
<!-- 						<a href="/" class="web_btn_a">Cardio Web</a> -->
<!-- 						<ul class="web_depth "> -->
<!-- 							<li><a href="">Cardio Web(KR)</a></li> -->
<!-- 							<li><a href="">Cardio Web(AU)</a></li> -->
<!-- 							<li><a href="">Cardio Web(UK)</a></li> -->
<!-- 						</ul> -->
<!-- 					</li> -->
<!-- 				</ul> -->
<!-- 			</button> -->
			<div class="lang_btn j_eng fs_18">
				<a href="/index.php" class="on">KR</a>
				<a href="/lang.php?lang=en">EN</a>
			</div>
		</div>
		<div class="hd_m_box">
			<div class="lang_box j_eng fs_12 font_r">
				<button class="m_lang_btn">KR <i><img src="/img/icon/hd_down_icon.png" alt=""></i></button>
					<ul>
						<li><a href="/index.php">KR</a></li>						
						<li><a href="/lang.php?lang=en">EN</a></li>
					</ul>			
				</div>
			<button class="nav_btn">
				<span></span>
				<span></span>
				<span></span>
			</button>
		</div>
		<div class="mobile_wrap">
			<div class="mo_inner">
				<nav class="mo_gnb j_eng">
					<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/page/page0101.php" class="fs_18 font_r "><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/page/page0101.php"><i>Overview</i></a></li>
			<li><a href="/page/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/page/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/page/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/page/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/page/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/page/page0204.php"><i>S-Patch AI</i></a></li>
<!--			<li><a href="/"><i>Interoperability</i></a></li>		-->
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news&sca=보도자료"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news&sca=이벤트"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news&sca=스토리"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry"><i>Inquiry</i></a></li>	
			<li><a href="/page/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> 
				</nav>
			</div>
		</div>
	</div>
	<div class="nav_2depth_bg"></div>
</header>


<script type="text/javascript">
//
//	jQuery(document).ready(function() {
//			$('.pop_content').show();
//	});
	//팝업 Close 기능
	function close_pop(flag) {
		 $('.pop_content').hide();
		
//		$('.pop_submit').hide();
//		$('.pop_cancel').hide();
	};

	
	
	// 세션 상태를 저장하기 위한 변수
	var sessionCookieConsent = sessionStorage.getItem("sessionCookieConsent");

	// 쿠키 동의 여부를 확인하고 팝업을 표시하는 함수
	function checkCookieConsent() {
		if (!getCookie("cookieConsent") && sessionCookieConsent !== "rejected") {
			document.getElementById("cookieConsent").style.display = "block";
		}
	}

	// 쿠키 동의 여부를 저장하는 함수
	function acceptCookies() {
		setCookie("cookieConsent", true, 365); // 쿠키를 1년간 유지
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키 거부 처리하는 함수
	function rejectCookies() {
		sessionStorage.setItem("sessionCookieConsent", "rejected"); // 세션에 쿠키 거부 상태 저장
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키를 설정하는 함수
	function setCookie(name, value, days) {
		var expires = "";
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			expires = "; expires=" + date.toUTCString();
		}
		document.cookie = name + "=" + (value || "") + expires + "; path=/";
	}

	// 쿠키를 가져오는 함수
	function getCookie(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') c = c.substring(1, c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
		}
		return null;
	}

	// 페이지 로드 시 쿠키 동의 여부를 확인
	window.onload = checkCookieConsent;


</script>

<!--쿠키 팝업-->
		<div class="pop_content" id="cookieConsent" style="display:none;">
			<section>
				<h5 class="fs_22 font_b">쿠키 설정</h5>
				<div class="pop_txt_wrap">
					
					<div class="pop_txt">					
						<div>
							<span class="fs_18 font_m">당사에서는 사용자들에 맞춰 사이트를 설정하고 사용자들이 사이트를 보다 원활하게 이용할 수 있도록 쿠키를 사용합니다.</span> <br>
							<span class="fs_18 font_m">만일 당사의 쿠키 사용 정책에 대해 더 알고 싶으신 경우에는</span>
							<a href="/page/page06.php" alt="개인정보처리방침 보기 " class="fs_18 font_b">개인정보처리방침</a> 
							<span class="fs_18 font_m">을 참고하여 주시기 바랍니다.</span>

						</div>
					</div>
					<div class="pop_btn">
						<button class="pop_submit fs_20 font_sb fc_f"  onClick="acceptCookies();">수락</button>
						<button class="pop_cancel fs_20 font_sb"  onClick="rejectCookies();">거부</button>
					</div>
				
				</div>
				

				<div class="pop_form" onClick="close_pop();">         
					<figure>
						<img src="/img/icon/close.png" alt="">
					</figure>
				</div>
			</section>			
		</div>


	<!---게시판 상단 설정 시작--->
	




<!---sub page css--->
<link rel="stylesheet" href="/css/j_sub.css">

<!---sub page js--->
<script src="/js/j_sub.js"></script>

<!---sub page start--->

<!--
<div class="sub_visual">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<h2 class="j_eng fs_48 font_sb base_color"></h2>
				<p class="j_eng fs_22 font_r sub_color01">Compatible with : phone · Tablet · Watch</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/sv_0201.png" alt="" class="pc_img">
					<img src="/img/sub/sv_0201_m.png" alt="" class="mo_img">
				</figure>
			</div>		
		</div>
	</div>	
</div>
<div class="sub_common_rel">
-->
	
	<!--<div class="sub_common">
		<div class="j_inner">
			<ul class="tabs">
				<li class="tab-link current" data-tab="tab-1">
					<h4 class="j_eng fs_22 base_color">Physician Web</h4> <!-- &page_tab01 -->
	<!--				<p class="fs_16 font_m base_color02">환자를 위한 실시간 심전도 모니터링</p>
				</li>
				<li class="tab-link" data-tab="tab-2">
					<h4 class="j_eng fs_22 base_color">ECG Report</h4> <!-- &page_tab02 -->
	<!--				<p class="fs_16 font_m base_color02">의료진을 위한 최적의 검사 효율화</p>
				</li>
			</ul>
		</div>
	</div>	-->







<script>
	
	$(function(){
		
		win_info();
		
		function win_info(){
			win_w = $(window).width()
			win_h = $(window).height()
			scr_t = $(window).scrollTop()
		}
		
		var head_h = $('#j_header').outerHeight()
		var tab_h = $('.sub_common').outerHeight()
		
		$('.tabs a').click(function() {
			$('.tabs a').parent('li').stop().removeClass('current');
			$(this).parent('li').stop().addClass('current');
			
			if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
				var $target = $(this.hash);
				var focusSecId = $target.attr("id");
				$target = $target.length && $target || $('[name=' + this.hash.slice(1) + ']');
				if ($target.length) {

					var head_h = $('#j_header').outerHeight() - $('.sub_common').outerHeight();

					if(win_w < '769'){
						var head_h = $('#j_header').outerHeight() ;
					}
					var targetOffset = $target.offset().top;

					
					$('html,body').animate({
						scrollTop: targetOffset
					},500,function(){

					});
					return false;
				}
			}
		});	
	
		
	})

</script>

<script>
// 스크롤 이벤트 리스너 추가
window.addEventListener('scroll', function() {
    var startSection = document.getElementById('web').getBoundingClientRect();
    var endSection = document.getElementById('web_end').getBoundingClientRect();
    var web = document.querySelector('#tab_web');
    var ai = document.querySelector('#tab_report');

    // 사용자가 시작 섹션과 끝 섹션 사이에 있을 때
    if(startSection.top < window.innerHeight && endSection.bottom > 500) {
        web.classList.add('current');
        ai.classList.remove('current');
    }else {
        web.classList.remove('current');
        ai.classList.add('current');
    }
		
});
	
	
</script>

<div class="sub_visual">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<span class="j_eng fs_18 font_b fc_f">S-Patch Web</span>
				<h2 class="fs_48 font_b base_color">판독부터 분석 리포트까지 <b style="white-space: nowrap">한 번에.</b></h2>
				<p class="fs_22 font_r sub_color01">데이터 분석 서비스와 함께 활용 가능</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/page02/page0203/sv_0203.jpg" alt="" >
				</figure>
			</div>		
		</div>
	</div>	
</div>


<div class="sub_common_rel page0203">
	<div class="sub_common">
		<div class="j_inner">
			<ul class="tabs">
				<li class="tab-link" id="tab_web">
					<a href="#web">
						<h4 class="j_eng fs_22 fc_f">Physician Web</h4> <!-- &page_tab01 -->
						<p class="fs_16 font_m fc_f"><b class="j_eng">S-Patch</b> 최적 판독 프로그램 및 분석 서비스</p>
					</a>
					
				</li>
				<li class="tab-link" id="tab_report">
					<a href="#start_report">
						<h4 class="j_eng fs_22 fc_f">ECG Report</h4> <!-- &page_tab02 -->
						<p class="fs_16 font_m fc_f">주요 부정맥을 포함한 최종 분석 결과 제공</p>
					</a>
					
					
				</li>
			</ul>
		</div>
		
	</div>

	<section class="sec01" id="web">
		<div class="j_inner">
			<div class="tit_box j_motion common_motion texc">
				<span class="j_eng font_r fs_16 tit_span">Web</span>
				<h2 class="tab_tit fs_48 font_b">
					우리가 모은 데이터는<br>
					우리가 가장 잘 분석하니까.
				</h2>
			</div><!--tit box-->
			<div class="content_wrap j_motion common_motion j_delay_01">
				<div class="con1_img_wrapper">
					<p class="fs_26 font_b lh_5 fc_f">
						<b class="j_eng">S-Patch</b> 솔루션에 최적화된 판독 프로그램, <br>
						<b class="j_eng">AI</b> 알고리즘을 활용한 1차 분석부터 분석 서비스 제공까지 
					</p>

					<figure>
						<img src="/img/sub/page02/page0203/con1.jpg" alt="" >
					</figure>				
				</div>
				
				<p class="mode_txt fs_18 fc_c"><b class="j_eng">Light-mode</b> (5월 중 출시 예정)</p>
			</div><!--content wrap-->	

			
		</div>
	</section>


	<section class="sec02">		
		<div class="tit_box j_motion common_motion">					
			<h2 class="fs_48 font_b">
				검사 시작부터 완료까지. <br class="mo_ver">과정은 쉽지만 결과는 완벽하게.
			</h2>
		</div><!--tit box-->

		<div class="web_slide_wrap j_motion common_motion">
			<ul>
				<li>
					<div class="slide_left">
						<a class="slide_tit_wrap">
							<h4 href="" class="slide_tit fs_32 font_b">검사 관리</h4>
							<span class="on"><img src="/img/sub/page02/page0203/con2_arrow.png" alt=""></span>
						</a>
						<div class="slide_txt_wrap">
							<p class="fs_18 font_m lh_5">
								대시보드에서 새로운 검사를 만들고 검사 상태를 관리할 수 있습니다.
								검사 정보를 잘못 입력했다면 언제든지 수정이 가능하죠. 리스트에서 
								보고 싶지 않은 검사는 숨기고, 특별히 표시하고 싶은 검사는 북마크를 
								설정하여 모아 볼 수 있습니다.
							</p>					
						</div>	
					</div>
					
					
					<div class="slide_right">
						<figure class="slide_img"><img src="/img/sub/page02/page0203/con2_1.jpg" alt=""></figure>
					</div>
					
				</li>
				<li>
					<div class="slide_left">
						<a class="slide_tit_wrap">
							<h4 href="" class="slide_tit fs_32 font_b">검사 판독</h4>
							<span><img src="/img/sub/page02/page0203/con2_arrow.png" alt=""></span>
						</a>
						<div class="slide_txt_wrap">
							<p class="slide_txt_cate fs_18 j_eng font_b">Trend · Shape · Event · Episode</p>
							<p class="fs_18 font_m lh_5">
								검사 시간 전체에 대한 심전도 데이터를 확인하고, 1차 분석된 데이터에 
								대한 판독을 진행할 수 있습니다. 분류된 파형 그룹들을 확인하고 비트나 
								리듬을 수정할 수 있습니다. 이상 파형의 발생 빈도와 심박 데이터 관련 
								에피소드 확인 및 원하는 구간의 스트립을 선택해 리포트에 추가하여 
								표시합니다.
							</p>					
						</div>			
					</div>
					
					<div class="slide_right">
						<figure class="slide_img"><img src="/img/sub/page02/page0203/con2_2.jpg" alt=""></figure>
					</div>		
				</li>
				<li>		
					<div class="slide_left">
						<a class="slide_tit_wrap">
							<h4 href="" class="slide_tit fs_32 font_b">검사 결과 제공</h4>
							<span><img src="/img/sub/page02/page0203/con2_arrow.png" alt=""></span>
						</a>
						<div class="slide_txt_wrap">
							<p class="slide_txt_cate fs_18 j_eng font_b">Report</p>
							<p class="fs_18 font_m lh_5">
								판독을 완료한 검사의 최종 결과를 리포트 탭에서 확인할 수 있습니다. <br>
								<b class="j_eng">PDF/JPG</b> 형태로 다운로드받아 환자 진료에 활용합니다.
							</p>		
<!--
							<a href="/page/page0204.php" class="j_eng fs_18 font_r">
								<i class="a_line fs_18 font_r fc_9">S-Patch ECG Report <b class="fs_18 font_m fc_9">더 알아보기</b></i>
								<i class="p_arrow"><img src="/img/sub/page02/page0203/btn_arrow.png" alt=""></i>
							</a>		
-->
						</div>	
					</div>
					
					<div class="slide_right">
						<figure class="slide_img"><img src="/img/sub/page02/page0203/con2_3.jpg" alt=""></figure>
					</div>	
				</li>
			</ul>
		</div><!--web_slide_wrap-->
	</section>

	<script>
		var slideButton = $('.slide_left .slide_tit_wrap');
		
		slideButton.click(function(){
		
			 // Check if the clicked element has the 'on' class
			if (!$(this).children('span').hasClass('on')) {
				// Remove 'on' class and slide up
				slideButton.find('span').removeClass('on');
//				$('.slide_left .slide_txt_wrap').stop().slideUp(300);
//				$('.slide_right').stop().fadeOut(300);
				
				if (window.innerWidth <= 1080) {
					$('.slide_left .slide_txt_wrap, .slide_right').stop().hide(0);
				} else {
					$('.slide_left .slide_txt_wrap').stop().slideUp(300);
					$('.slide_right').stop().fadeOut(300);
				}

				// Add 'on' class and slide down
				$(this).children('span').stop().addClass('on');
				$(this).siblings('.slide_txt_wrap').slideDown(300);
				$(this).parent('.slide_left').siblings('.slide_right').fadeIn(300);
			}
		})
		
		if (matchMedia("screen and (max-width: 1080px)").matches) {
			slideButton.click(function(){
				
				if (!$(this).children('span').hasClass('on')) {
					slideButton.find('span').removeClass('on');
//					$('.slide_left .slide_txt_wrap').stop().hide(0).slideUp(0);			
//					$('.slide_right').stop().hide(0).fadeOut(0);
					$('.slide_left .slide_txt_wrap, .slide_right').stop().hide();

					$(this).children('span').stop().addClass('on');
					$(this).siblings('.slide_txt_wrap').slideDown(300);
					$(this).parent('.slide_left').siblings('.slide_right').slideDown(300);	
					
				}
						
			}) 
  		}
    	
	</script>
	
	
	<section class="sec03" id="web_end">
		<div class="j_inner">
			<div class="tit_box j_motion common_motion texc">
				<span class="j_eng font_r fs_16 tit_span">Analysis Service</span>
				<h2 class="tab_tit fs_48 font_b">
					판독 효율성 극대화. <br class="mo_ver">분석 완료까지 <b style="color: #6138b0; ">신속하게</b>.
				</h2>
				<p class="fs_20 font_sb lh_5" style="color: #7b7b7b;">
					<b class="font_b" style="color: #000; ">분석 서비스</b>는 <b class="j_eng">S-Patch</b>로 수집된 데이터를 정리 및 분석하여 진료를 위한 리포트를 병원에 제공합니다. <br>
					진행되는 검사 건수가 많은 경우나 병원 내 판독 가능 인원이 부족한 경우, 빠른 검사 결과를 받기 위해서 분석 서비스를 활용할 수 있습니다.
				</p>	
				<a href="/bbs/write.php?bo_table=inquiry" class="j_eng fs_18 font_r">
					<i class="a_line fs_18 font_m">분석 서비스 활용 문의하기</b></i>
					<i class="p_arrow"><img src="/img/sub/page02/page0203/btn_arrow_p.png" alt=""></i>
				</a>
			</div><!--tit box-->
		</div>
	
	
		<div class="content_wrap">
			<ul>
				<li >
					<div class="j_motion common_motion02 j_delay_01">
						<h4 class="fs_32 font_sb fc_f">외래 분석서비스</h4>
						<div class="sec03_con_box">
							<figure><img src="/img/sub/page02/page0203/con3_1.png" alt=""></figure>

							<div class="sec03_con_txt">
								<p class="fs_20 font_sb fc_f">
									<b class="j_eng">S-Patch</b> 솔루션이 도입된 병의원에서 패치형 심전도 검사로 수집된 환자 데이터를 판독하여 병의원 전용 리포트를 제공합니다.
								</p>
								<p class="fs_20 font_r" style="color: #e4e4e4;">서비스 활용 대상</p>
								<p class="fs_20 font_r" style="color: #e4e4e4;">병의원</p>
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="j_motion common_motion02 j_delay_03">
						<h4 class="fs_32 font_sb fc_f">건강검진 분석서비스</h4>
						<div class="sec03_con_box">
							<figure><img src="/img/sub/page02/page0203/con3_2.png" alt=""></figure>

							<div class="sec03_con_txt">
								<p class="fs_20 font_sb fc_f">
									<b class="j_eng">S-Patch</b> 솔루션이 도입된 건강검진센터에서 검사 후 수집된 환자 데이터를 판독하여 건진용 리포트를 제공합니다.
								</p>
								<p class="fs_20 font_r" style="color: #e4e4e4;">서비스 활용 대상</p>
								<p class="fs_20 font_r" style="color: #e4e4e4;">건진센터</p>
							</div>
						</div>
						<p class="fs_16 font_r sec03_p lh_5"  style="color: #e4e4e4;">
							*건강검진 검사의 경우, 분석 서비스와 함께 <b class="font_b">디바이스 케어 (기기 수거 및 관리) 서비스</b>가 제공됩니다.
						</p>
					</div>
				</li>
			</ul>
		</div>	<!--content wrap-->
	</section>

	<section class="sec04" id="start_report">
		<div class="j_inner">
			<div class="tit_box j_motion common_motion">
				<span class="j_eng font_r fs_16 tit_span">Report</span>
				<h2 class="tab_tit fs_48 font_b">
					진료에 필요한 정보만 읽기 쉽게. <br>
					업계 최고의 가독성.
				</h2>

			</div><!--tit box-->

			<div class="content_wrap">
				<p class="fs_22 font_sb lh_5 j_motion common_motion j_delay_01">
					의료진이 검사 후 중요한 정보를 한 눈에 파악할 수 있도록, <br class="br_480x">
					판독이 완료된 검사에 대해 주요 부정맥을 포함한 분석 결과가 정리되어 리포트로 제공됩니다.
				</p>
				<ul>
					<li class="j_motion common_motion j_delay_02"><figure><img src="/img/sub/page02/page0204/con1_1.jpg" alt="" ></figure></li>
					<li class="j_motion common_motion j_delay_03"><figure><img src="/img/sub/page02/page0204/con1_2.jpg" alt="" ></figure></li>
				</ul>
			</div>
		</div>
	</section>


	<section class="sec05">
		<div class="sec05_sticky_wrap">
			
			
			<div class="sticky_wrap">
				<div class="sticky_bg sticky_bg1">
					<figure class="report_p report_p1">
						<img src="/img/sub/page02/page0203/con2_p1.png" alt="">
					</figure>

					<figure class="report_p report_p2">
						<img src="/img/sub/page02/page0203/con2_p2.png" alt="">
					</figure>

					<figure class="report_p report_p3">
						<img src="/img/sub/page02/page0203/con2_p3.png" alt="">
					</figure>

					<figure class="report_p report_p4">
						<img src="/img/sub/page02/page0203/con2_p4.png" alt="">
					</figure>

					<figure class="report_p report_p5">
						<img src="/img/sub/page02/page0203/con2_p5.png" alt="">
					</figure>

				</div>
				<div class="sticky_bg sticky_bg2">
					<figure class="report_p report_p6">
						<img src="/img/sub/page02/page0203/con2_p1.png" alt="">
					</figure>

					<figure class="report_p report_p7">
						<img src="/img/sub/page02/page0203/con2_p2.png" alt="">
					</figure>

					<figure class="report_p report_p8">
						<img src="/img/sub/page02/page0203/con2_p4.png" alt="">
					</figure>
				</div>
				<div class="sticky_bg sticky_bg3">				
					<figure class="report_p report_p9">
						<img src="/img/sub/page02/page0203/con2_p3.png" alt="">
					</figure>

					<figure class="report_p report_p10">
						<img src="/img/sub/page02/page0203/con2_p5.png" alt="">
					</figure>

				</div>

				<div class="sticky_tit_box j_motion common_motion j_delay_04">	
					<div class="sticky_tit">
						<h2 class="j_motion common_motion j_delay_01 fs_48 font_b texc">
							궁금한 모든 것은 <br>
							하나의 리포트 안에
						</h2>
					</div>
					<div class="sticky_txt j_motion common_motion j_delay_05">
						<p class="fs_20 font_m lh_5" style="color: #646464;">검사의 완성도는 결과로 보여주어야 합니다.</p>
						<p class="fs_20 font_m lh_5" style="color: #646464;">
							검사 중 기록된 부정맥 이벤트들에 대한 유의미한 분석 결과를 제공합니다. 
							전체 요약 통계부터 상세한 증상 일지 기록, 심박 관련 중요 데이터 테이블과
							그래프, 이상 파형 및 리듬 스트립 등 검사로 진단할 수 있는 부정맥 증상과 관련된
							모든 중요한 순간들의 정보를 빠르고 읽기 쉽게 확인할 수 있습니다.

						</p>
					</div>
				</div>
			</div>		
		</div><!--sec05_sticky_wrap-->
		
	</section>

<script>
	window.addEventListener('scroll', function() {
		const stickyBgRect = document.querySelector('.sticky_bg').getBoundingClientRect();
		const scrollYRelativeToStickyBg = window.scrollY - stickyBgRect.top;

		if (scrollYRelativeToStickyBg >= 0) {
			let report_p1_top = 0;
			let report_p2_top = 0;
			let report_p3_top = 0;
			let report_p4_top = 0;
			let report_p5_top = 0;
			
			if (window.innerWidth <= 1280) {
				report_p1_top = `${scrollYRelativeToStickyBg * 0.06 - 200}px`;
				report_p2_top = `${900 - scrollYRelativeToStickyBg * 0.1}px`;
				report_p3_top = `${1150 - scrollYRelativeToStickyBg * 0.06}px`;
				report_p4_top = `${scrollYRelativeToStickyBg * 0.08 - 150}px`;
				report_p5_top = `${scrollYRelativeToStickyBg * 0.15 - 100}px`;
			} 

			/*pc형*/
			else {
				report_p1_top = `${scrollYRelativeToStickyBg * 0.04 - 200}px`;
				report_p2_top = `${900 - scrollYRelativeToStickyBg * 0.08}px`;
				report_p3_top = `${1700 - scrollYRelativeToStickyBg * 0.1}px`;
				report_p4_top = `${scrollYRelativeToStickyBg * 0.15 - 600}px`;
				report_p5_top = `${scrollYRelativeToStickyBg * 0.2 - 400}px`;
			}
			
			document.querySelector('.report_p1').style.top = report_p1_top;
			document.querySelector('.report_p2').style.top = report_p2_top;
			document.querySelector('.report_p3').style.top = report_p3_top;
			document.querySelector('.report_p4').style.top = report_p4_top;
			document.querySelector('.report_p5').style.top = report_p5_top;
		}
	});
</script>
<script>
	window.addEventListener('scroll', function() {
		const stickyBgRect = document.querySelector('.sticky_bg2').getBoundingClientRect();
		const scrollYRelativeToStickyBg = window.scrollY - stickyBgRect.top;

		if (scrollYRelativeToStickyBg >= 0) {
			let report_p6_top = 0;
			let report_p7_top = 0;
			let report_p8_top = 0;
			let report_p9_top = 0;
			let report_p10_top = 0;
			
			if (window.innerWidth <= 767) {
				report_p6_top = `${scrollYRelativeToStickyBg * 0.06 - 200}px`;
				report_p7_top = `${scrollYRelativeToStickyBg * 0.09 - 120}px`;
				report_p8_top = `${scrollYRelativeToStickyBg * 0.07 - 100}px`;
				report_p9_top = `${scrollYRelativeToStickyBg * 0.03 - 10}px`;
				report_p10_top = `${scrollYRelativeToStickyBg * 0.04 - 10}px`;
			} 
//			else if (window.innerWidth <= 480) {
//				report_p6_top = `${scrollYRelativeToStickyBg * 0.08 - 200}px`;
//				report_p7_top = `${1080 - scrollYRelativeToStickyBg * 0.1}px`;
//				report_p8_top = `${1400 - scrollYRelativeToStickyBg * 0.06}px`;
//				report_p9_top = `${scrollYRelativeToStickyBg * 0.13 - 200}px`;
//				report_p10_top = `${scrollYRelativeToStickyBg * 0.2 - 100}px`;
//			} 
			/*1080px*/
			else {
				report_p6_top = `${scrollYRelativeToStickyBg * 0.08 - 180}px`;
				report_p7_top = `${scrollYRelativeToStickyBg * 0.12 - 20}px`;
				report_p8_top = `${scrollYRelativeToStickyBg * 0.08 - 70}px`;
				report_p9_top = `${scrollYRelativeToStickyBg * 0.05 - 100}px`;
				report_p10_top = `${scrollYRelativeToStickyBg * 0.08 - 100}px`;
			}
			
			document.querySelector('.report_p6').style.top = report_p6_top;
			document.querySelector('.report_p7').style.top = report_p7_top;
			document.querySelector('.report_p8').style.top = report_p8_top;
			document.querySelector('.report_p9').style.top = report_p9_top;
			document.querySelector('.report_p10').style.top = report_p10_top;
		}
	});
</script>
	

	<section class="sec06">
		<div class="j_inner">
			<div class="tit_box j_motion common_motion ">
				<h5 class="tab_tit fs_48 font_b">
					검사 환경에 맞는 리포트 옵션 선택.
				</h5>

				<a href="/bbs/write.php?bo_table=inquiry" class="j_eng fs_18 font_r">
					<i class="a_line fs_18 font_m fc_9">리포트 데모 요청하기</i>
					<i class="p_arrow"><img src="/img/sub/page02/page0203/btn_arrow.png" alt=""></i>
				</a>

			</div><!--tit box-->	
			<ul class="content_wrap">
				<li class="j_motion common_motion j_delay_01">
					<figure><img src="/img/sub/page02/page0204/con3_1.jpg" alt=""></figure>
					<div class="sec03_txt">
						<h5 class="fs_22 font_b">병의원 리포트</h5>
						<p class="fs_18 font_m" style="color: #838383;">
							주요 부정맥을 포함한 검사의 전체 통계를 제공합니다. 환자가 검사 기간 동안 기록한 증상 일지와 해당 시간의 심전도 스트립이 표시되며, 심박 관련 데이터들과 이상 파형 및 리듬에 해당하는 스트립 정보들이 제공됩니다.
						</p>
					</div>					
				</li>
				<li class="j_motion common_motion j_delay_02">
					<figure><img src="/img/sub/page02/page0204/con3_2.jpg" alt=""></figure>
					<div class="sec03_txt">
						<h5 class="fs_22 font_b">건진용 리포트</h5>
						<p class="fs_18 font_m" style="color: #838383;">
							패치형 심전도 검사를 진행한 일반 수검자의 건진 결과를 제공합니다. 분석 시간 및 심박에 대한 기본 정보와 부정맥 동반 여부 및 증상 관찰 등에 대한 이벤트 정보들이 제공되며, 부정맥 진단의 중요성을 알리는 정보가 함께 제공됩니다.
					</div>					
				</li>
				<li class="j_motion common_motion j_delay_03">
					<figure><img src="/img/sub/page02/page0204/con3_3.jpg" alt=""></figure>
					<div class="sec03_txt">
						<h5 class="fs_22 font_b"><b class="j_eng">Full Disclosure</b> 리포트</h5>
						<p class="fs_18 font_m" style="color: #838383;">
							검사 시간 전체에 대한 모든 스트립을 표시합니다. 전체 검사 시간 내 이상 파형 또는 리듬이 발생한 시간 및 지속 여부를 한 눈에 확인할 수 있기 때문에 짧은 시간 안에 빠르고 정확한 분석 및 진단이 가능합니다.
						</p>
					</div>					
				</li>
			</ul>
		</div>

	</section>
	<section class="sub_page_banner page0102 page0202 page0203 sub_btn_wrapper">
		<div class="j_inner">
			<ul class="p0202_list p0201_list">	
				<li class="p0202_rt p0201_rt">
					<a href="/page/page0202_ex.php" class="fs_18 font_m j_eng">
						<i class="btn_icon">
							<img src="/img/icon/btn_icon_b_l.png" alt="" class="btn_icon_b">
						</i>
						S-Patch App						
					</a>
				</li>
				<li class="p0202_rt p0201_rt">
					<a href="/page/page0204.php" class="fs_18 font_m j_eng">
						S-Patch AI
						<i class="btn_icon">
							<img src="/img/icon/btn_icon_b.png" alt="" class="btn_icon_b">
						</i>
					</a>
				</li>
			</ul>
		</div>
	</section>
	
</div>








<div class="side_rail">
	<div class="side_bar">
		<ul>
		 
			<li><a href="javascript:;" class="demo_btn j_eng fs_18 font_r" id="openinquiry">DEMO</a></li>
					<li><a href="/" class="top_btn j_eng fs_18 font_r">TOP</a></li>
		</ul>
		<div class="side_close">
			<a href="/" class="plus_btn"><img src="/img/icon/side_bar_icon.png" alt=""></a>
		</div>
	</div>
</div>
    <footer class="j_footer">
			<div class="main main_05">
				<div class="j_inner02">
					<div class="sec_tit">
						<h2><img src="/img/logo/hd_logo_m_w.png" alt=""></h2>
					</div>
					<ul class="main_05_list j_eng fs_16 font_r j_motion common_motion">
						<li>
							<a href="/page/page0101.php" class="sub_tit">Company</a>
							<a href="/page/page0101.php" class="">Overview</a>
							<a href="/page/page0102.php">Team</a>
							<a href="/bbs/board.php?bo_table=cert">IP</a>
						</li>
						<li>
							<a href="/page/page0201.php" class="sub_tit">S-Patch</a>
							<a href="/page/page0201.php" class="">S-Patch Wear</a>
							<a href="/page/page0202_ex.php">S-Patch App</a>
							<a href="/page/page0203.php">S-Patch Web</a>
							<a href="/page/page0204.php">S-Patch AI</a>
<!--							<a href="/">interoperability</a>	-->
						</li>
<!--
						<li>
							<a href="/" class="sub_tit">Service</a>
							<a href="/" class="">Field</a>
							<a href="/">Use Cases</a>
						</li>
-->
						<li>
							<a href="/bbs/board.php?bo_table=news" class="sub_tit">News</a>
							<a href="/bbs/board.php?bo_table=news&sca=보도자료" class="">Press</a>
							<a href="/bbs/board.php?bo_table=news&sca=이벤트">Event</a>
							<a href="/bbs/board.php?bo_table=news&sca=스토리">Story</a>
						</li>
						<li>
							<a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="sub_tit">Support</a>
							<a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="">Manual / FAQ</a>
							<a href="/bbs/write.php?bo_table=inquiry">Inquiry</a>
							<a href="/page/page0503.php">Contact</a>
						</li>
						<li>
							<a class="sub_tit" style="cursor: pointer;">S-Patch Web</a>
							<a href="https://kr.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(KR)</a>
							<a href="https://au.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(AU)</a>
							<a href="https://uk.spatchcardio.com/spa/html/login.html" class="" target="_blank">S-Patch Web(EU)</a>
						</li>
						<li class="down_box">
							
							<p class="sub_tit_down font_m">Download</p>
							<a href="/download/wellysis_brochure_kr.pdf" class="down_btn" target="_blank">Brochure <i><img src="/img/icon/down_arrow.png" alt=""></i></a>
							<a href="/page/page06.php" class="sub_tit" style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">개인정보처리방침</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="j_inner02">
				<div class="ft_cont">
					<div class="ft_lb">
						<p class="j_eng fs_16 font_r">
<!--							<i>Address: 8F, 425 Teheran-ro, Gangnam-gu, <br class="mo_br"> Seoul, Republic of Korea</i> <br>-->
							<i style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">본사 : 서울시 강남구 테헤란로 425, 8층</i> 
							<br>
							<i class="mt_5"><b style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">미국 지사 :</b> JLABS@TMC, 2450 Holcombe Blvd Suite J, Houston, TX 77021, United States</i>
							<br>
							<i class="mt_5">CEO : Young Juhn</i> <i class="bf_i mt_5">Business License : 774-87-01381</i> <br>
							<i class="mt_5">Phone : + 82 1800 2830</i> <i class="bf_i mt_5">Email : info@wellysis.com</i>
						</p>	
					</div>
					<div class="ft_rb">
						<div class="ft_link">
							<a href="https://youtube.com/@S-Patch?si=iN4f7lZHv_KQGTFE" target="_blank"><img src="/img/icon/you_icon.png" alt="" ></a>
							<a href="https://www.linkedin.com/company/wellysis/" target="_blank"><img src="/img/icon/in_icon.png" alt="" ></a>
						</div>
						<p class="j_eng fs_16 font_l">© Wellysis | All rights reserved 2024						
						
														<a href="/bbs/login.php?url=../../index.php" style="color:#666;">ADMIN</a>
													</p>
					</div>
				</div>		
			</div>
    </footer>

<style>
.inquiry_overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
}

.overlay-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70vw;
  height: 90vh;
  background-color: #fff;
  padding: 30px 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  border-radius:30px;
  padding: 20px 10px;
}

#closeinquiry {
  position: absolute;
  top: 50px;
  right: 60px;
  color: #fff;
  border: none;
  cursor: pointer;
 
}

.overlay-content iframe {
  width: 100%;
  height: 100%;
}
	
@media (max-width: 1280px){
	#closeinquiry {top: 20px; right: 20px; }
}
@media (max-width: 767px){
	.overlay-content{width: 80vw; height: 80vh;}
}
@media (max-width: 360px){
	.overlay-content{width: 90vw;}
	#closeinquiry {top: 15px; right: 15px;}
}
</style>

 
	<div id="inquiry_overlay" class="inquiry_overlay">
	  <div class="overlay-content">
		<button id="closeinquiry"><img src="/img/icon/demo_close.svg" alt=""></button>
		<iframe src="/bbs/write.php?bo_table=inquiry&pop=y" frameborder="0"></iframe>
	  </div>
	</div>

<script>
document.getElementById('openinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'block';
});

document.getElementById('closeinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'none';
});
</script>






</body>
</html>
