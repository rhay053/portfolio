
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


<meta name="description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta name="keywords" content="웰리시스, wellysis, Wellysis, 지능형 알고리즘, 삼성, 삼성 스마트 헬스 프로세서, 디지털 솔루션, 심전도 검사, 실혈관질환 검사" />
<meta property="og:type" content="article">
<meta property="og:title" content="Wellysis">
<meta property="og:description" content="진단에서 예방으로, 헬스케어의 변화를 이끌다">
<meta property="og:url" content="https://www.wellysis.com/">
<title>Wellysis</title>
<link rel="stylesheet" href="https://www.wellysis.com/theme/wellysis/css/mobile.css?ver=2303229">
<link rel="stylesheet" href="https://www.wellysis.com/js/font-awesome/css/font-awesome.min.css?ver=2303229">


<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">

<title>Wellysis</title>
<meta property="og:title" content="Wellysis" />
<meta property="og:type" content="website" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<meta property="og:description" content="" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Robots" content="INDEX, FOLLOW" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" href="/favicon.ico?v=2" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico?v=2" type="image/x-icon">

<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css" />
<link rel="stylesheet" href="/css/j_reset.css">
<link rel="stylesheet" href="/css/j_style.css">
<link rel="stylesheet" href="/css/interwise_all_board.css">
<link rel="stylesheet" href="/css/k_all_board.css">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js" integrity="sha512-qF6akR/fsZAB4Co1QDDnUXWnaQseLGXoniuSuSlPQK6+aWhlMZcHzkasCSlnWoe+TJuudlka1/IQ01Dnhgq95g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollTrigger/1.0.6/ScrollTrigger.min.js" integrity="sha512-+LXqbM6YLduaaxq6kNcjMsQgZQUTdZp7FTaArWYFt1nxyFKlQSMdIF/WQ/VgsReERwRD8w/9H9cahFx25UDd+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="//code.jquery.com/jquery-latest.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
<script src="/js/j_main.js"></script>



<!--[if lte IE 8]>
<script src="https://www.wellysis.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "https://www.wellysis.com";
var g5_bbs_url   = "https://www.wellysis.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "1";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
	
	
	
	<!-- Google Analytics -->

	<script async src="https://www.googletagmanager.com/gtag/js?id=G-TMD9VCEFJ1"></script>

	<script>  

		window.dataLayer = window.dataLayer || [];  
		function gtag(){dataLayer.push(arguments);}  

		gtag('js', new Date());   
		gtag('config', 'G-TMD9VCEFJ1');

	</script>


	<!-- Naver Analytics -->

	<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>

	<script type="text/javascript">
		
		if(!wcs_add) var wcs_add = {};
		wcs_add["wa"] = "a4cd9bf8185038";

		if(window.wcs) {

		  wcs_do();

		}

	</script>
	
<script src="https://www.wellysis.com/js/jquery-1.12.4.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery-migrate-1.4.1.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/jquery.menu.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/common.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/wrest.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/placeholders.min.js?ver=2304171"></script>
<script src="https://www.wellysis.com/js/modernizr.custom.70111.js?ver=2304171"></script>
</head>
<body oncontextmenu="return false" ondragstart="return false">
<!--영문 스타일-->
<link rel="stylesheet" href="/css/j_sub_en.css">

<header id="j_header" class="fixed">
	<div class="j_hd_con">
		<h1 class="hd_logo">
			<a href="/" id="logoLink">
				<img src="/img/logo/hd_logo.svg" alt="" class="hd_w">
				<img src="/img/logo/hd_logo_m_w.png" alt="" class="hd_m_w">
		
				<img src="/img/logo/hd_logo_b.svg" alt="" class="hd_b">
				<img src="/img/logo/hd_logo_m_b.png" alt="" class="hd_m_b">		
		</a>	
		</h1>
		<div class="hd_right_box">
			<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/page/page0101.php" class="fs_18 font_r "><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/page/page0101.php"><i>Overview</i></a></li>
			<li><a href="/page/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/page/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/page/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/page/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/page/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/page/page0204.php"><i>S-Patch AI</i></a></li>
<!--			<li><a href="/"><i>Interoperability</i></a></li>		-->
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news&sca=보도자료"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news&sca=이벤트"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news&sca=스토리"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry"><i>Inquiry</i></a></li>	
			<li><a href="/page/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> <!-- 			<button class="web_btn fs_18 font_r j_eng"> -->
<!-- 				<ul> -->
<!-- 					<li> -->
<!-- 						<a href="/" class="web_btn_a">Cardio Web</a> -->
<!-- 						<ul class="web_depth "> -->
<!-- 							<li><a href="">Cardio Web(KR)</a></li> -->
<!-- 							<li><a href="">Cardio Web(AU)</a></li> -->
<!-- 							<li><a href="">Cardio Web(UK)</a></li> -->
<!-- 						</ul> -->
<!-- 					</li> -->
<!-- 				</ul> -->
<!-- 			</button> -->
			<div class="lang_btn j_eng fs_18">
				<a href="/index.php" class="on">KR</a>
				<a href="/lang.php?lang=en">EN</a>
			</div>
		</div>
		<div class="hd_m_box">
			<div class="lang_box j_eng fs_12 font_r">
				<button class="m_lang_btn">KR <i><img src="/img/icon/hd_down_icon.png" alt=""></i></button>
					<ul>
						<li><a href="/index.php">KR</a></li>						
						<li><a href="/lang.php?lang=en">EN</a></li>
					</ul>			
				</div>
			<button class="nav_btn">
				<span></span>
				<span></span>
				<span></span>
			</button>
		</div>
		<div class="mobile_wrap">
			<div class="mo_inner">
				<nav class="mo_gnb j_eng">
					<ul class="j_gnb">
    <li class="j_menu_1 j_eng">
        <a href="/page/page0101.php" class="fs_18 font_r "><i>Company</i></a>
		<ul class="depth02">
			<li><a href="/page/page0101.php"><i>Overview</i></a></li>
			<li><a href="/page/page0102.php"><i>Team</i></a></li>
			<li><a href="/bbs/board.php?bo_table=cert"><i>IP</i></a></li>
		</ul>
    </li>

    <li class="j_menu_2 j_eng">
        <a href="/page/page0201.php" class="fs_18 font_r"><i>S-Patch</i></a>
		<ul class="depth02">
			<li><a href="/page/page0201.php"><i>S-Patch Wear</i></a></li>
			<li><a href="/page/page0202_ex.php"><i>S-Patch App</i></a></li>
			<li><a href="/page/page0203.php"><i>S-Patch Web</i></a></li>
			<li><a href="/page/page0204.php"><i>S-Patch AI</i></a></li>
<!--			<li><a href="/"><i>Interoperability</i></a></li>		-->
		</ul>
    </li>

<!--
    <li class="j_menu_3 j_eng">
        <a href="#" class="fs_18 font_r"><i>Service</i></a>
		<ul class="depth02">
			<li><a href="/"><i>Field</i></a></li>
			<li><a href="/"><i>Use Cases</i></a></li>	
		</ul>

    </li>
-->

    <li class="j_menu_4 j_eng">
        <a href="/bbs/board.php?bo_table=news" class="fs_18 font_r"><i>News</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=news&sca=보도자료"><i>Press</i></a></li>
			<li><a href="/bbs/board.php?bo_table=news&sca=이벤트"><i>Event</i></a></li>	
			<li><a href="/bbs/board.php?bo_table=news&sca=스토리"><i>Story</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_5 j_eng">
        <a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="fs_18 font_r"><i>Support</i></a>
		<ul class="depth02">
			<li><a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비"><i>Manual / FAQ</i></a></li>
			<li><a href="/bbs/write.php?bo_table=inquiry"><i>Inquiry</i></a></li>	
			<li><a href="/page/page0503.php"><i>Contact</i></a></li>	
		</ul>
    </li>
	<li class="j_menu_6 j_eng">
		<a class="fs_18 font_r" style="cursor: pointer;"><span>S-Patch Web</span></a>
		<ul class="depth02">
			<li><a href="https://kr.spatchex.com/" target="_blank"><i>S-Patch Web(KR)</i></a></li>
			<li><a href="https://au.spatchex.com/" target="_blank"><i>S-Patch Web(AU)</i></a></li>
			<li><a href="https://uk.spatchcardio.com/" target="_blank"><i>S-Patch Web(EU)</i></a></li>
		</ul>
	</li>
</ul> 
				</nav>
			</div>
		</div>
	</div>
	<div class="nav_2depth_bg"></div>
</header>


<script type="text/javascript">
//
//	jQuery(document).ready(function() {
//			$('.pop_content').show();
//	});
	//팝업 Close 기능
	function close_pop(flag) {
		 $('.pop_content').hide();
		
//		$('.pop_submit').hide();
//		$('.pop_cancel').hide();
	};

	
	
	// 세션 상태를 저장하기 위한 변수
	var sessionCookieConsent = sessionStorage.getItem("sessionCookieConsent");

	// 쿠키 동의 여부를 확인하고 팝업을 표시하는 함수
	function checkCookieConsent() {
		if (!getCookie("cookieConsent") && sessionCookieConsent !== "rejected") {
			document.getElementById("cookieConsent").style.display = "block";
		}
	}

	// 쿠키 동의 여부를 저장하는 함수
	function acceptCookies() {
		setCookie("cookieConsent", true, 365); // 쿠키를 1년간 유지
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키 거부 처리하는 함수
	function rejectCookies() {
		sessionStorage.setItem("sessionCookieConsent", "rejected"); // 세션에 쿠키 거부 상태 저장
		document.getElementById("cookieConsent").style.display = "none";
	}

	// 쿠키를 설정하는 함수
	function setCookie(name, value, days) {
		var expires = "";
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			expires = "; expires=" + date.toUTCString();
		}
		document.cookie = name + "=" + (value || "") + expires + "; path=/";
	}

	// 쿠키를 가져오는 함수
	function getCookie(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') c = c.substring(1, c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
		}
		return null;
	}

	// 페이지 로드 시 쿠키 동의 여부를 확인
	window.onload = checkCookieConsent;


</script>

<!--쿠키 팝업-->
		<div class="pop_content" id="cookieConsent" style="display:none;">
			<section>
				<h5 class="fs_22 font_b">쿠키 설정</h5>
				<div class="pop_txt_wrap">
					
					<div class="pop_txt">					
						<div>
							<span class="fs_18 font_m">당사에서는 사용자들에 맞춰 사이트를 설정하고 사용자들이 사이트를 보다 원활하게 이용할 수 있도록 쿠키를 사용합니다.</span> <br>
							<span class="fs_18 font_m">만일 당사의 쿠키 사용 정책에 대해 더 알고 싶으신 경우에는</span>
							<a href="/page/page06.php" alt="개인정보처리방침 보기 " class="fs_18 font_b">개인정보처리방침</a> 
							<span class="fs_18 font_m">을 참고하여 주시기 바랍니다.</span>

						</div>
					</div>
					<div class="pop_btn">
						<button class="pop_submit fs_20 font_sb fc_f"  onClick="acceptCookies();">수락</button>
						<button class="pop_cancel fs_20 font_sb"  onClick="rejectCookies();">거부</button>
					</div>
				
				</div>
				

				<div class="pop_form" onClick="close_pop();">         
					<figure>
						<img src="/img/icon/close.png" alt="">
					</figure>
				</div>
			</section>			
		</div>


	<!---게시판 상단 설정 시작--->
	




<!---sub page css--->
<link rel="stylesheet" href="/css/j_sub.css">

<!---sub page js--->
<script src="/js/j_sub.js"></script>

<!---sub page start--->

<!--
<div class="sub_visual">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<h2 class="j_eng fs_48 font_sb base_color"></h2>
				<p class="j_eng fs_22 font_r sub_color01">Compatible with : phone · Tablet · Watch</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/sv_0201.png" alt="" class="pc_img">
					<img src="/img/sub/sv_0201_m.png" alt="" class="mo_img">
				</figure>
			</div>		
		</div>
	</div>	
</div>
<div class="sub_common_rel">
-->
	
	<!--<div class="sub_common">
		<div class="j_inner">
			<ul class="tabs">
				<li class="tab-link current" data-tab="tab-1">
					<h4 class="j_eng fs_22 base_color">Physician Web</h4> <!-- &page_tab01 -->
	<!--				<p class="fs_16 font_m base_color02">환자를 위한 실시간 심전도 모니터링</p>
				</li>
				<li class="tab-link" data-tab="tab-2">
					<h4 class="j_eng fs_22 base_color">AI</h4> <!-- &page_tab02 -->
	<!--				<p class="fs_16 font_m base_color02">의료진을 위한 최적의 검사 효율화</p>
				</li>
			</ul>
		</div>
	</div>	-->




<style>
	.main_05{position: relative; z-index: 10;}
</style>


<div class="sub_visual page0201_vs page0204_vs">
	<div class="j_inner">
		<div class="sv_cont">
			<div class="sub_tit_box j_motion common_motion02">
				<span class="j_eng fs_18 font_b fc_f">S-Patch AI</span>
				<h2 class="fs_48 font_b base_color">완벽한 분석을 위한 <br class="mo_ver">알고리즘의 여정.</h2>
				<p class="fs_22 font_r sub_color01">고품질 라벨링 데이터 학습을 통해 향상된 분석 능력</p>
			</div>
			<div class="sub_img_box j_motion common_motion">
				<figure>
					<img src="/img/sub/page02/page0204/sv_0204.jpg" alt="" >
				</figure>
			</div>		
		</div>
	</div>	
</div>


<div class="sub_common_rel page0201 page0204"  id="roadmap">
	
	<section class="sec01">
		
		<div class="j_inner">
	
			<div class="tit_box j_motion common_motion txtc">
				<span class="j_eng font_r fs_16 tit_span">AI</span>
				<h2 class="tab_tit fs_48 font_b">
					점점 더 <br class="br_480o">완벽해지는 성능. <br>
					높아지는 <br class="br_480o">1차 분석의 퀄리티. 
				</h2>

			</div><!--tit box-->			

			<div class="content_wrap">
				<ul>
					<li>
						<div class="con1_tit">
							<span class="fs_18 font_b j_eng">01</span>
							<h3 class="fs_28 font_b">중요한 것은 고객의 검증</h3>
						</div>
						<p class="fs_20 fc_2 font_r">
							심장 모니터링과 부정맥 진단 지원을 위해 <br>글로벌 파트너들에게 검증받은 솔루션입니다.
						</p>
					</li>
					<li>
						<div class="con1_tit">
							<span class="fs_18 font_b j_eng">02</span>
							<h3 class="fs_28 font_b">정확도가 만드는 속도의 차이</h3>
						</div>
						<p class="fs_20 fc_2 font_r">
							높은 정확도로 빠르게 데이터 해석과 진단이 가능한 <br>서비스를 제공합니다.
						</p>
					</li>
					<li>
						<div class="con1_tit">
							<span class="fs_18 font_b j_eng">03</span>
							<h3 class="fs_28 font_b">ECG 레이크하우스</h3>
						</div>
						<p class="fs_20 fc_2 font_r">
							다양한 환자들의 심전도 데이터를 담고 있는 웰리시스의 <br>데이터베이스를 기반으로 한 DNN 기술을 적용합니다.
						</p>
					</li>
				</ul>

				<figure class="j_motion common_motion02">
					<img src="/img/sub/page02/page0203/con4_m.jpg" alt="">
				</figure>
			</div><!--content_wrap-->
		</div>
	</section>

	<section class="sec02">
		<div class="tit_box j_motion common_motion txtc">
			<h3 class="fs_48 font_b fc_f texc" >
				학습을 통한 성장. <br class="br_768o">성장을 통한 학습 강화.
			</h3>		
		</div><!--tit box-->
		
		<div class="content_wrap">
			<ul>
				<li class="j_motion common_motion j_delay_01">
					<h4 class="j_eng fs_72 fc_f font_b">15</h4>
					
					<p class="con2_tit fs_20 fc_f font_b">서비스 사용 국가</p>
					<p class="fs_18 fc_f font_r">미국, 유럽, 아시아, <br>오세아니아 권역</p>
				</li>
				<li class="j_motion common_motion j_delay_02">
					<h4 class="j_eng fs_72 fc_f font_b">790<b class="fc_8f">+</b></h4>
					
					<p class="con2_tit fs_20 fc_f font_b">헬스케어 서비스 제공 기관</p>
					<p class="fs_18 fc_f font_r">3차 의료기관, 1차 의료기관 <br>및 검진 센터</p>
				</li>
				<li class="j_motion common_motion j_delay_03">
					<h4 class="j_eng fs_72 fc_f font_b">1.5<b class="fs_54">M</b></h4>
					
					<p class="con2_tit fs_20 fc_f font_b">이상의 심전도 검사 시간 진행</p>
					<p class="fs_18 fc_f font_r">스크리닝 기준 50만 시간, <br>심방세동(AF) 라벨링된 심박 기준 10만 시간 이상</p>
				</li>
				<li class="j_motion common_motion j_delay_04">
					<h4 class="j_eng fs_72 fc_f font_b">6<b class="fs_54">B</b></h4>
					
					<p class="con2_tit fs_20 fc_f font_b">라벨링된 심박 데이터</p>
					<p class="fs_18 fc_f font_r">심전도 검사를 통해 확보된 100만 시간 이상의 데이터. 그 중 30만 시간의 AF 심박 데이터</p>
				</li>
			</ul>
		</div>
	</section>
	
	<script>

		$(document).ready(function() {
			// Function for starting PC animation
			function startPCAnimation() {
				var repeatInterval = 12000;

				pcAnimation(); // Start PC animation

				// Re-execute PC animation after repeatInterval
				setInterval(pcAnimation, repeatInterval);
			}

			// PC version animation
			function pcAnimation() {
				$('.sub_list>li.listCount_sub1').removeClass('on');
				$('.sub_list>li').removeClass('on');
				$('.sub_list>li.listCount_sub1').addClass('on');

				var no = 2;
				var intervalSpeed = 2000;

				var tid0 = setInterval(function() {
					$('.sub_list>li.listCount_sub' + no).addClass('on');
					no++;
					if (no > 6) {
						clearInterval(tid0);
					}
				}, intervalSpeed);

				$('.sub_progressbar').addClass('progress-started');
			}

			startPCAnimation();

		});
		
		
		
		
		$(document).ready(function() {
	
			// Function for starting mobile animation
			function startMobileAnimation() {
				var repeatInterval2 = 12000;

				mobileAnimation(); // Start PC animation

				// Re-execute PC animation after repeatInterval
				setInterval(mobileAnimation, repeatInterval2);
			}

			// Mobile version animation
			function mobileAnimation() {
				$('.sub_list_mo>li.mo_listCount_sub1').removeClass('on');
				$('.sub_list_mo>li').removeClass('on');
				$('.sub_list_mo>li.mo_listCount_sub1').addClass('on');

				var no = 2;
				var intervalSpeed2 = 2000;

				var tid1 = setInterval(function() {
					$('.sub_list_mo>li.mo_listCount_sub' + no).addClass('on');
					no++;
					if (no > 6) {
						clearInterval(tid1);
					}
				}, intervalSpeed2);

				$('.mo_sub_progressbar').addClass('mo_progress-started');
			}

			startMobileAnimation();
		});
	</script>	

	<section class="sec03" id="platform">
		<!--platform start-->
		<div class="platform_pc">
			<div class="j_inner">			
				<div class="tit_box j_motion common_motion txtc">
					<h2 class="fs_48 font_b" >심전도 분석 플랫폼</h2>	
					<p class="fs_20 font_m lh_5">
						<b class="j_eng">ECG Lakehouse</b>는 <b class="font_b" style="color: #000; ">정제 및 라벨링된 심전도 데이터</b>들의 수집과 선택을 자동화하여 전반적인 분석 파이프라인을 간소화합니다.
					</p>	
				</div><!--tit box-->
			</div><!--j inner-->
			<section class="sub_pro j_motion j_inner">
				<div class="sub_pro_cont main01_cont j_motion common_motion">
					<ul class="sub_list">
						<div class="sub_progressbar">
							<span class="sub_progress"></span>				
						</div>

						<li class="listCount_sub1">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Selection</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="listCount_sub2">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Labeling <br>&<br>Curation</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="listCount_sub3">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Exploring</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="listCount_sub4">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Training <br>&<br>Clustering</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="listCount_sub5">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Validation</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="listCount_sub6">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Evaluation <br>&<br>Deployment</h3>
							</div>
							<span class="light_b"></span>
						</li>
					</ul>
				</div>
			</section>
		</div><!--platform_pc-->
			
			
		<div class="platform_mo">
			<div class="j_inner">			
				<div class="tit_box j_motion common_motion txtc">
					<h2 class="fs_48 font_b" >심전도 분석 플랫폼</h2>	
					<p class="fs_20 font_m lh_5">
						<b class="j_eng">ECG Lakehouse</b>는 <b class="font_b" style="color: #000; ">정제 및 라벨링된 심전도 데이터</b>들의 수집과 선택을 자동화하여 전반적인 분석 파이프라인을 간소화합니다.
					</p>	
				</div><!--tit box-->
			</div><!--j inner-->
			<section class="sub_pro j_motion j_inner">
				<div class="sub_pro_cont main01_cont j_motion common_motion">
					<ul class="sub_list sub_list_mo">
						<div class="mo_sub_progressbar">
							<span class="mo_sub_progress"></span>				
						</div>

						<li class="mo_listCount_sub1">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Selection</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="mo_listCount_sub2">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Labeling <br>& <br>Curation</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="mo_listCount_sub3">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Exploring</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="mo_listCount_sub4">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Training <br>& <br>Clustering</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="mo_listCount_sub5">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Validation</h3>
							</div>
							<span class="light_b"></span>
						</li>
						<li class="mo_listCount_sub6">					
							<div class="sub_desc">
								<h3 class="j_eng fs_20 font_sb">Evaluation <br>& <br>Deployment</h3>
							</div>
							<span class="light_b"></span>
						</li>
					</ul>
				</div>
			</section>
		
		</div><!--platform_mo-->
		<!--platform end-->
		
		
		
		<div class="j_inner">
			<ul class="content_wrap">
				<li class="j_motion common_motion j_delay_01">
					<figure><img src="/img/sub/page02/page0203/con5_1.svg" alt=""></figure>
					<h5 class="fs_22 font_b fc_f">데이터 수집</h5>					

					<ul class="content_txt_wrap">
						<li>
							<span></span><p class="fs_18 font_m fc_f">상업 또는 자체 수집 데이터</p>
						</li>
						<li>
							<span></span><p class="fs_18 font_m fc_f">퍼블릭 데이터</p>
						</li>
						<li>
							<span></span><p class="fs_18 font_m fc_f">임상 연구</p>
						</li>
					</ul>

				</li>
				<li class="j_motion common_motion j_delay_02">
					<figure><img src="/img/sub/page02/page0203/con5_2.svg" alt=""></figure>
					<h5 class="fs_22 font_b fc_f">데이터 레이크하우스</h5>					

					<ul class="content_txt_wrap">
						<li>
							<span></span><p class="fs_18 font_m fc_f">성능 모니터링</p>
						</li>
						<li>
							<span></span><p class="fs_18 font_m fc_f">쿼리 최적화</p>
						</li>
						<li>
							<span></span><p class="fs_18 font_m fc_f">마이그레이션 엔진</p>
						</li>
					</ul>
				</li>
				<li class="j_motion common_motion j_delay_03">
					<figure><img src="/img/sub/page02/page0203/con5_3.svg" alt=""></figure>
					<h5 class="fs_22 font_b fc_f">데이터 분석</h5>					

					<ul class="content_txt_wrap">
						<li>
							<span></span><p class="fs_18 font_m fc_f">통계 분석</p>
						</li>
						<li>
							<span></span><p class="fs_18 font_m fc_f">데이터 시각화</p>
						</li>
						<li>
							<span></span><p class="fs_18 font_m fc_f">모델 유효성 검사</p>
						</li>
					</ul>
				</li>
			</ul>
		</div>		
	</section>

	
	
	<section class="sub0102_con2">
		<div class="j_inner">
			<div class="content_wrap">
				<div class="tit_box j_motion common_motion">
					<h2 class="fs_48 font_b">
						개인 건강 로드맵
					</h2>
					<p class="fs_20 font_m lh_5">
						<b class="j_eng">ECG</b> 분석에서 <b class="font_b">다중 생체 신호 분석 및 예방</b>으로 범위를 확장시켜, <b class="j_eng">S-Patch AI</b>는 <b class="font_b">종합적인 개인 건강 분석</b>을 제공하는 것을 목표로 합니다.
					</p>
				</div><!--tit box-->	
				
				<div class="wtz_wrapper">
					<div class="wtz_box wtz_box_01">
						<div class="wtz_left j_motion common_motion">
							<h3 class="fs_28 font_b fc_3" style="color: #4e4e4e;">심전도 모니터링</h3>							
						</div><!--wtz left-->
						
						<div class="wtz_right j_motion common_motion02">
							<ul>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">부정맥 진단</h4>
										<p class="fs_18 font_m fc_f">
											고품질의 훈련된 데이터로 <br>정확도 향상
										</p>
									</div>
								</li>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">심전도 분석 보고서</h4>
										<p class="fs_18 font_m fc_f">
											ECG 통계, 지표 및 히스토그램
										</p>
									</div>
								</li>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">스트레스 수준 스코어링</h4>
										<p class="fs_18 font_m fc_f">
											심박변이(HRV) 지표를 <br>활용한 스트레스 수준 파악
										</p>
									</div>
								</li>
														
							</ul>
						</div><!--wtz right-->
					</div><!--wtz box-->
					
					<div class="wtz_box wtz_box_02">
						<div class="wtz_left j_motion common_motion">
							<h3 class="fs_28 font_b fc_3" style="color: #4e4e4e;">모션 분석</h3>							
						</div><!--wtz left-->
						
						<div class="wtz_right j_motion common_motion02">
							<ul>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">자세 분석</h4>
										<p class="fs_18 font_m fc_f">
											심전도와 함께 자세 정보를 <br>자동으로 기록
										</p>
									</div>
								</li>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">활동</h4>
										<p class="fs_18 font_m fc_f">
											운동자각도 (Rating of Perceived <br>Exertion; RPE) 지속 기록
										</p>
									</div>
								</li>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">낙상 감지</h4>
										<p class="fs_18 font_m fc_f">
											실신, 낙상을 자동으로 감지하고 <br>알림 제공
										</p>
									</div>
								</li>
														
							</ul>
						</div><!--wtz right-->
					</div><!--wtz box-->
					
					<div class="wtz_box wtz_box_03">
						<div class="wtz_left j_motion common_motion">
							<h3 class="fs_28 font_b fc_3" style="color: #4e4e4e;">개인 건강 분석</h3>			
							<p class="fs_16 font_r fc_9">
								개발 중, 2024년 4분기 출시 예정
							</p>
						</div><!--wtz left-->
						
						<div class="wtz_right j_motion common_motion02">
							<ul>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">부정맥 예방</h4>
										<p class="fs_18 font_m fc_f">
											부정맥의 조기 징후 예측 <br>또는 발견
										</p>
									</div>
								</li>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">다중 생체 신호 감지</h4>
										<p class="fs_18 font_m fc_f">
											온도, 체지방, 호흡 속도 등을 <br>활성화
										</p>
									</div>
								</li>
								<li>
									<span></span>
									<div class="wtz_txt">
										<h4 class="fs_20 font_b fc_f">수면 분석</h4>
										<p class="fs_18 font_m fc_f">
											수면 품질 감지 및 <br>수면 무호흡 위험 추정
										</p>
									</div>
								</li>
														
							</ul>
						</div><!--wtz right-->
					</div><!--wtz box-->
				</div><!--wtz wrapper-->
			</div><!--content wrapper-->
		</div>		
	</section>
	<section class="sub_page_banner page0102 page0204 sub_btn_wrapper">
		<div class="j_inner">
			<ul class="p0202_list p0201_list">					
				<li class="p0202_rt p0201_rt">
					<a href="/page/page0203.php" class="fs_18 font_m j_eng">
						<i class="btn_icon">
							<img src="/img/icon/btn_icon_b_l.png" alt="" class="btn_icon_b">
						</i>
						S-Patch Web
					</a>
				</li>
			</ul>
		</div>
	</section>
</div>








<div class="side_rail">
	<div class="side_bar">
		<ul>
		 
			<li><a href="javascript:;" class="demo_btn j_eng fs_18 font_r" id="openinquiry">DEMO</a></li>
					<li><a href="/" class="top_btn j_eng fs_18 font_r">TOP</a></li>
		</ul>
		<div class="side_close">
			<a href="/" class="plus_btn"><img src="/img/icon/side_bar_icon.png" alt=""></a>
		</div>
	</div>
</div>
    <footer class="j_footer">
			<div class="main main_05">
				<div class="j_inner02">
					<div class="sec_tit">
						<h2><img src="/img/logo/hd_logo_m_w.png" alt=""></h2>
					</div>
					<ul class="main_05_list j_eng fs_16 font_r j_motion common_motion">
						<li>
							<a href="/page/page0101.php" class="sub_tit">Company</a>
							<a href="/page/page0101.php" class="">Overview</a>
							<a href="/page/page0102.php">Team</a>
							<a href="/bbs/board.php?bo_table=cert">IP</a>
						</li>
						<li>
							<a href="/page/page0201.php" class="sub_tit">S-Patch</a>
							<a href="/page/page0201.php" class="">S-Patch Wear</a>
							<a href="/page/page0202_ex.php">S-Patch App</a>
							<a href="/page/page0203.php">S-Patch Web</a>
							<a href="/page/page0204.php">S-Patch AI</a>
<!--							<a href="/">interoperability</a>	-->
						</li>
<!--
						<li>
							<a href="/" class="sub_tit">Service</a>
							<a href="/" class="">Field</a>
							<a href="/">Use Cases</a>
						</li>
-->
						<li>
							<a href="/bbs/board.php?bo_table=news" class="sub_tit">News</a>
							<a href="/bbs/board.php?bo_table=news&sca=보도자료" class="">Press</a>
							<a href="/bbs/board.php?bo_table=news&sca=이벤트">Event</a>
							<a href="/bbs/board.php?bo_table=news&sca=스토리">Story</a>
						</li>
						<li>
							<a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="sub_tit">Support</a>
							<a href="/bbs/board.php?bo_table=FAQ&sca=검사+준비" class="">Manual / FAQ</a>
							<a href="/bbs/write.php?bo_table=inquiry">Inquiry</a>
							<a href="/page/page0503.php">Contact</a>
						</li>
						<li>
							<a class="sub_tit" style="cursor: pointer;">S-Patch Web</a>
							<a href="https://kr.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(KR)</a>
							<a href="https://au.spatchex.com/spa/html/login.html" class="" target="_blank">S-Patch Web(AU)</a>
							<a href="https://uk.spatchcardio.com/spa/html/login.html" class="" target="_blank">S-Patch Web(EU)</a>
						</li>
						<li class="down_box">
							
							<p class="sub_tit_down font_m">Download</p>
							<a href="/download/wellysis_brochure_kr.pdf" class="down_btn" target="_blank">Brochure <i><img src="/img/icon/down_arrow.png" alt=""></i></a>
							<a href="/page/page06.php" class="sub_tit" style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">개인정보처리방침</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="j_inner02">
				<div class="ft_cont">
					<div class="ft_lb">
						<p class="j_eng fs_16 font_r">
<!--							<i>Address: 8F, 425 Teheran-ro, Gangnam-gu, <br class="mo_br"> Seoul, Republic of Korea</i> <br>-->
							<i style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">본사 : 서울시 강남구 테헤란로 425, 8층</i> 
							<br>
							<i class="mt_5"><b style="font-family: 'Pretendard Variable', Pretendard, sans-serif;">미국 지사 :</b> JLABS@TMC, 2450 Holcombe Blvd Suite J, Houston, TX 77021, United States</i>
							<br>
							<i class="mt_5">CEO : Young Juhn</i> <i class="bf_i mt_5">Business License : 774-87-01381</i> <br>
							<i class="mt_5">Phone : + 82 1800 2830</i> <i class="bf_i mt_5">Email : info@wellysis.com</i>
						</p>	
					</div>
					<div class="ft_rb">
						<div class="ft_link">
							<a href="https://youtube.com/@S-Patch?si=iN4f7lZHv_KQGTFE" target="_blank"><img src="/img/icon/you_icon.png" alt="" ></a>
							<a href="https://www.linkedin.com/company/wellysis/" target="_blank"><img src="/img/icon/in_icon.png" alt="" ></a>
						</div>
						<p class="j_eng fs_16 font_l">© Wellysis | All rights reserved 2024						
						
														<a href="/bbs/login.php?url=../../index.php" style="color:#666;">ADMIN</a>
													</p>
					</div>
				</div>		
			</div>
    </footer>

<style>
.inquiry_overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
}

.overlay-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70vw;
  height: 90vh;
  background-color: #fff;
  padding: 30px 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  border-radius:30px;
  padding: 20px 10px;
}

#closeinquiry {
  position: absolute;
  top: 50px;
  right: 60px;
  color: #fff;
  border: none;
  cursor: pointer;
 
}

.overlay-content iframe {
  width: 100%;
  height: 100%;
}
	
@media (max-width: 1280px){
	#closeinquiry {top: 20px; right: 20px; }
}
@media (max-width: 767px){
	.overlay-content{width: 80vw; height: 80vh;}
}
@media (max-width: 360px){
	.overlay-content{width: 90vw;}
	#closeinquiry {top: 15px; right: 15px;}
}
</style>

 
	<div id="inquiry_overlay" class="inquiry_overlay">
	  <div class="overlay-content">
		<button id="closeinquiry"><img src="/img/icon/demo_close.svg" alt=""></button>
		<iframe src="/bbs/write.php?bo_table=inquiry&pop=y" frameborder="0"></iframe>
	  </div>
	</div>

<script>
document.getElementById('openinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'block';
});

document.getElementById('closeinquiry').addEventListener('click', function() {
  document.getElementById('inquiry_overlay').style.display = 'none';
});
</script>






</body>
</html>
